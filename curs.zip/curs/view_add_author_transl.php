<?php 
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include ('database/connection.php'); ?>
        <meta charset="utf-8"> <!-- Кодировка страницы -->
        <!-- Бибдиотеки BOOTSTRAP и JQuery -->
        <link rel="stylesheet" href="lib/bootstrap-4.2.1/css/bootstrap.css">
        <script src="lib/js/jquery-3.3.1.js"></script>
        <script src="lib/js/popper.min.js"></script>
        <script src="lib/bootstrap-4.2.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css_file.css"> <!-- Мои стили -->
        <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> <!-- Шрифт -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Добавить</title>
        <script src="/main.js"></script>
    </head>
    <body>
        <?php include ('header.php'); ?>

        <?php 
        //include ('database/entities.php'); 
        $conn = new MyConnection();
        ?>

        <div class="main">
            <form action="add_all.php"  method="post">
                <div class="container form-group card my-5 p-4 shadow-md">
                    <h2 class="text-center pb-3"> Авторы </h2>
                    <?php foreach($conn->getAuthors() as $i => $author) { ?>

                    <div id="<?=$author['id_Author']?>_author" class="<?php if ($i > 0) { echo 'border-top '; }  ?> d-flex flex-row justify-content-between py-2">
                        <div class="d-flex flex-row">
                            <div class="h4 mr-2"><?=$author['AFullName']?></div>
                        </div>
                        <div class="btn btn-outline-danger" onclick="deleteAuthor('<?=$author['id_Author']?>_author')">Удалить</div>
                    </div>
                    <?php } ?>
                    <h2 class="pt-3"> Добавление автора </h2>
                    <div class="row" id="reg-form">
                        <div class="col-sm">
                            <label style="font-size: 25px">Полное Имя</label>
                            <input type="text" class="form-control" name="afullname" placeholder="" >
                        </div>
                        <div class="col-sm">
                            <label style="font-size: 25px">Путь к фото</label>
                            <input type="text" class="form-control" name="afoto" placeholder="" >
                        </div>
                        <div class="col-sm">
                            <label style="font-size: 25px">Дата рождения</label>
                            <input type="date" class="form-control" name="adate" placeholder="" >
                        </div>
                    </div>
                    <div class="row" id="reg-form">
                        <div class="col-sm">
                            <label style="font-size: 25px">Описание</label>
                            <textarea type="text" class="form-control" name="adescription" placeholder="" ></textarea>
                        </div>
                    </div>
                    <div class="mt-4 text-center">
                        <button class="btn btn-light" type="submit" name="action" value="add_author" style="font-size: 20px">
                                    Добавить
                        </button>
                    </div>    
                </div> 
            </form>

            <div class="main">
            <form action="add_all.php"  method="post">
                <div class="container form-group card my-5 p-4 shadow-md">
                    <h2 class="text-center pb-3"> Переводчики </h2>
                    <?php foreach($conn->getTranslators() as $i => $translator) { ?>

                    <div id="<?=$translator['id_Translator']?>_translator" class="<?php if ($i > 0) { echo 'border-top '; }  ?> d-flex flex-row justify-content-between py-2">
                        <div class="d-flex flex-row">
                            <div class="h4 mr-2"><?=$translator['TFullName']?></div>
                        </div>
                        <div class="btn btn-outline-danger" onclick="deleteTranslator('<?=$translator['id_Translator']?>_translator')">Удалить</div>
                    </div>
                    <?php } ?>
                    <h2 class="pt-3"> Добавление переводчика </h2>
                    <div class="row" id="reg-form">
                        <div class="col-sm">
                            <label style="font-size: 25px">Полное Имя</label>
                            <input type="text" class="form-control" name="tfullname" placeholder="" >
                        </div>
                    </div>
                    <div class="mt-4 text-center">
                        <button class="btn btn-light" type="submit" name="action" value="add_trans" style="font-size: 20px">
                                    Добавить
                        </button>
                    </div>        
                </div> 
            </form>
        </div>
        
        <!-- Подвал страницы -->
        <?php include ('footer.php'); ?>

    </body>
</html>