<?php 
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include ('database/connection.php'); ?>
        <meta charset="utf-8"> <!-- Кодировка страницы -->
        <!-- Бибдиотеки BOOTSTRAP и JQuery -->
        <link rel="stylesheet" href="lib/bootstrap-4.2.1/css/bootstrap.css">
        <script src="lib/js/jquery-3.3.1.js"></script>
        <script src="lib/js/popper.min.js"></script>
        <script src="lib/bootstrap-4.2.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css_file.css"> <!-- Мои стили -->
        <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> <!-- Шрифт -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="/main.js"></script>
        <title>Мой профиль</title>
    </head>
    <body>
        <?php include ('header.php'); ?>
        <?php 
        //include ('database/entities.php'); 
        $conn = new MyConnection();
        //$user = $conn->getUserByID($_GET["!!!user_id!!!"]);
        ?>
        <div class="main">
            <div style="padding-bottom: 50px;">
                <div class="container">
                    <h1><span class="letter">М</span>ои данные.</h1></br>
                    <div class="container form-group card p-2">
                        <div class="row" id="reg-form">
                            <div class="indent" style="font-size:20px;">
                                <p>Имя: <?= $user['UName'] ?></p>
                                <p>Дата рождения: <?= (new DateTime($user['UDate_of_Birth']))->format('d.m.Y') ?></p>
                                <p>Почта: <?= $user['UEmail'] ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="mt-4 text-center">
                        <a class="btn btn-light" href='/auth.php?sign_out=yes' style="font-size: 20px">Выйти</a>
                    </div>
                    
                    <div class="container mb-4 mt-4">
                    <h1><span class="letter">К</span>ниги на полке.</h1></br>
                    <div class="row" style="text-align: left;">


                        <?php foreach ($conn->getReservedBooks($user) as $book) { ?>
                        
                        <div class="col-sm-6 col-md-4 col-lg-3 col-12 pr" id='<?=$book['id_Book']?>' style="margin-bottom: 30px;">
                            <a class="name-prepod" href="view_book.php?book_id=<?= $book["id_Book"] ?>">
                                <div class="book-image" style="background: url('<?= $book['Cover'] ?>'); background-size: contain; background-position: center;">
                                </div>
                                <hr style="width: 100%; border: none; background-color: #000; height: 2px;">
                                <span><?= $book['Title'] ?></span> </br>
                            </a>
                            
                                <span class="author_text"><?= $book['AFullName']?></span> 
                            
                            </br>
                            <div class="btnmar">
                                <?php if (!empty($user)) { ?>
                                    <?php if (in_array($book['id_Book'], $reservedBooks)) { ?>
                                        <button class="btn btn-light" onclick="removeReservation('<?= $book["id_Book"] ?>', this, true)">Убрать</button>
                                    <?php } else { ?>
                                        <button class="btn btn-light" onclick="addReservation('<?= $book["id_Book"] ?>', this)">Отложить</button>
                                    <?php } ?>
                                <?php } else { ?>
                                    <a href="/sign_in.php" class="btn btn-light">Отложить</a>
                                <?php } ?>

                            </div>
                            

                        </div>

                        <?php } ?>
                    </div>
            </div>
                </div>
            </div>
        
        </div>
        
        <!-- Подвал страницы -->
        <?php include ('footer.php'); ?>
        
    </body>
</html>
