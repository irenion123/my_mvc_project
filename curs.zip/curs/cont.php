<?php 
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"> <!-- Кодировка страницы -->
        <!-- Бибдиотеки BOOTSTRAP и JQuery -->
        <link rel="stylesheet" href="lib/bootstrap-4.2.1/css/bootstrap.css">
        <script src="lib/js/jquery-3.3.1.js"></script>
        <script src="lib/js/popper.min.js"></script>
        <script src="lib/bootstrap-4.2.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css_file.css"> <!-- Мои стили -->
        <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> <!-- Шрифт -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Контакты</title> 
    </head>

    <body>
        <?php include ('header.php'); ?>
        <div class="main">         
            <!-- Контентная часть -->
            <div style="padding-bottom: 20px;">
                <div class="container mt-4" id="cont">




                    <div style="padding-bottom: 20px;">
                        <div class="container mt-4" id="cont">
                            <div class="row align-items-center" style="text-align: center;">    
                                                        <!-- Контактные данные -->
                                <div class="col-lg-6 col-12 align-middle" style="text-align: left;">
                                    <div class="contel">
                                        <div class="author_text" style="text-indent: 20px">
                                            <p>
                                                Sed ut perspiciatis, unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam eaque ipsa, quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt, explicabo. Nemo enim ipsam 
                                            </p>
                                            <p>  
                                                Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint
                                            </p>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                                        </div>
                                        

                                    </div>
                                </div> 


                                <!-- Карта -->
                                <div class="col-lg-6 col-12 align-middle"><img src="slider/biblioteka.png" width="550" alt="альтернативный текст"></div>

                            </div>
                        </div>
                    </div> 
                    


                     <div>
                        <form action="cont.php" method="post">
                            <p style="font-size: 25px; margin-top: 15px;">Используйте форму ниже, чтобы связаться с нами: </p>
                            <div class="container form-group card p-4">
                                <div class="row" id="reg-form">
                                    <div class="col-md-6 col-12">
                                        <label style="font-size: 25px">Ваше имя:</label>
                                        <input type="text" class="form-control" name="name" placeholder="Введите Ваше имя" required> 
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <label style="font-size: 25px">Ваша электронная почта:</label>
                                        <input type="email" class="form-control" name="email" placeholder="Введите Вашу почту" required>
                                    </div>
                                    <div class="col-md-12 col-12">
                                        <label style="font-size: 25px">Ваше сообщение:</label>
                                        <textarea class="form-control" name="message" rows="5" placeholder="Напишите свое сообщение" required></textarea>
                                    </div>
                                </div>
                                <div class="mt-4 text-center"><input class="btn btn-light" name="send" type="submit" value="Отправить" style="font-size: 20px"></div>
                            </div>
                        </form>
                        <?php 
                            // Отслеживаем передачу данных методом POST
                            if($_POST['send']){
                                //занносим данные в переменные
                                $name = htmlspecialchars($_POST['name']);
                                $email = htmlspecialchars($_POST['email']);
                                $message = htmlspecialchars($_POST['message']);
                                $to = 'sosnina.ira16@gmail.com';
                                $tema = 'Отзыв с сайта от '.$email.' '.$name;
                                //указываем от кого письмо
                                $header = "From: ".$email;

                                //отправляем письмо
                                $sended = mail($to, $tema, $message, $header);
                            }
                        ?>
                    </div>








                    <div class="row align-items-center" style="text-align: center;">    
                        <!-- Карта -->
                        <div class="col-lg-6 col-12 align-middle"><iframe src="https://yandex.ru/map-widget/v1/-/CCCkVW46" width="100%" height="400px" frameborder="0" allowfullscreen="true"></iframe></div>
                        <!-- Контактные данные -->
                        <div class="col-lg-6 col-12 align-middle" style="text-align: left;">
                            <div class="contel">
                                <p>Адрес: г. Москва, Староватутинский проезд, дом 8, корп. 1, пом. 112</p>
                                <p>Часы работы: <br>
                                <span>Пн - Пт. 9:00 – 18:00</span> </p>
                                <p>Контакты:</p> 
                                <span class="tel">+7 (900) 000-00-00</span><br>
                                <a href="mailto:izdatelstvo@mail.ru">izdatelstvo@mail.ru</a>
                            </div>
                        </div> 
                    </div>

                   
                </div>
            </div>          
        </div>

        <!-- Подвал страницы -->
        <?php include ('footer.php'); ?>

    </body>
</html>