-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3307
-- Время создания: Июн 11 2021 г., 20:22
-- Версия сервера: 8.0.19
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `curs`
--

-- --------------------------------------------------------

--
-- Структура таблицы `authors`
--

CREATE TABLE `authors` (
  `id_Author` int NOT NULL,
  `AFullName` varchar(200) NOT NULL,
  `ADate_of_Birth` date DEFAULT NULL,
  `ADescription` varchar(500) DEFAULT NULL,
  `Foto` varchar(40) DEFAULT 'fotos/no_foto.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `authors`
--

INSERT INTO `authors` (`id_Author`, `AFullName`, `ADate_of_Birth`, `ADescription`, `Foto`) VALUES
(1, 'Сара Дж. Маас', '2021-05-01', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(2, 'Керри Манискалко', '2021-05-02', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(3, 'Виктория Авеярд', '2021-05-03', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(4, 'Холли Блэк', '2021-05-04', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(5, 'Лия Арден', '2021-05-05', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(6, 'Антонина Крейн', '2021-05-06', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(7, 'Риттер Уильям', '2021-05-07', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(8, 'Аннетт Мари', '2021-05-08', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(9, 'Синди Энсти', '2021-05-09', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(10, 'Татьяна Полякова', '2021-05-10', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(11, 'Миэ Со', '2021-05-11', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(12, 'Карризи Донато', '2021-05-12', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(13, 'Марисса Мейер', '2021-05-13', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(14, 'Анастасия Гор', '2021-05-14', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(15, 'Патрик Несс', '2021-05-15', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(16, 'Стивен Кинг', '2021-05-16', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(17, 'Брайан Герберт', '2021-05-17', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(18, 'Кевин Андерсон', '2021-05-18', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'fotos/no_foto.jpg'),
(20, 'Василий Пупкин', '2021-03-06', 'Блабла', 'fotos/no_foto.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `books`
--

CREATE TABLE `books` (
  `id_Book` int NOT NULL,
  `Title` varchar(100) DEFAULT NULL,
  `BDescription` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
  `ISBN` varchar(20) DEFAULT NULL,
  `YDK` varchar(20) DEFAULT NULL,
  `BBK` varchar(20) DEFAULT NULL,
  `id_Category` int DEFAULT NULL,
  `id_Seria` int DEFAULT NULL,
  `id_Cycle` int DEFAULT NULL,
  `id_Format` int DEFAULT NULL,
  `Year` int DEFAULT NULL,
  `Number_of_pages` int DEFAULT NULL,
  `Weight` double DEFAULT NULL,
  `Age` varchar(45) DEFAULT NULL,
  `Cover` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'covers/no_cover.jpg',
  `Сirculation` int DEFAULT NULL,
  `Binding` varchar(15) DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  `is_Shown` tinyint(1) DEFAULT '1',
  `Number_in_Cycle` int DEFAULT NULL,
  `is_Best` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `books`
--

INSERT INTO `books` (`id_Book`, `Title`, `BDescription`, `ISBN`, `YDK`, `BBK`, `id_Category`, `id_Seria`, `id_Cycle`, `id_Format`, `Year`, `Number_of_pages`, `Weight`, `Age`, `Cover`, `Сirculation`, `Binding`, `Status`, `is_Shown`, `Number_in_Cycle`, `is_Best`) VALUES
(1, 'Стеклянный трон', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-389-04531-6', NULL, NULL, 1, 1, 1, 1, 2012, 480, 0.25, '16', 'covers/1.jpg', 5000, 'твердый', 'вышла', 1, 1, 1),
(2, 'Охота на Джека-Потрошителя', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-17-982482-4', NULL, NULL, 2, 2, 2, 2, 2018, 416, 0.39, '16', 'covers/2.jpg', NULL, 'твердый', 'вышла', 1, 1, 0),
(3, 'Алая королева', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-04-103445-0', NULL, NULL, 1, 5, 3, 2, 2019, 544, 0.5, '16', 'covers/3.jpg', 30000, 'твердый', 'вышла', 1, 1, 1),
(4, 'Мара и Морок', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-04-107175-2', NULL, NULL, 1, 3, 4, 2, 2020, 384, 0.38, '16', 'covers/4.jpg', 42000, 'твердый', 'вышла', 1, 2, 0),
(5, 'Шолох. Теневые блики', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-04-111933-1', NULL, NULL, 1, 4, 5, 1, 2021, 544, 0.45, '16', 'covers/5.jpg', 5000, 'мягкий', 'вышла', 1, 1, 0),
(6, 'Королевство гнева и тумана', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-389-12106-5', NULL, NULL, 1, 1, 6, 2, 2017, 704, 0.1, '16', 'covers/6.jpg', 5000, 'твердый', 'вышла', 1, 2, 0),
(7, 'Kingdom of the Wicked', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', NULL, NULL, NULL, 2, 2, NULL, NULL, 2021, NULL, NULL, NULL, 'covers/7.jpg', NULL, 'твердый', 'права куплены', 1, 1, 0),
(8, 'Жестокий принц', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-04-090470-9', NULL, NULL, 1, 5, 7, 2, 2018, 480, 0.46, '16', 'covers/8.jpg', 41000, 'твердый', 'вышла', 1, 1, 0),
(9, 'Золото в темной ночи', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-04-111953-9', NULL, NULL, 1, 3, 8, 2, 2020, 384, 0.42, '16', 'covers/9.jpg', 12000, 'твердый', 'вышла', 1, 1, 0),
(10, 'Джекаби', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-17-105104-4', NULL, NULL, 2, 6, NULL, 2, 2018, 320, 0.3, '12', 'covers/10.jpg', NULL, 'твердый', 'вышла', 1, 1, 0),
(11, 'Алая зима', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-17-114127-1', NULL, NULL, 1, 5, NULL, 2, 2019, 384, 0.38, '16', 'covers/11.jpg', NULL, 'твердый', 'вышла', 1, 1, 0),
(12, 'Кинжал-Колибри', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-17-119470-3', NULL, NULL, 2, 6, NULL, 2, 2021, 416, 0.41, '16', 'covers/12.jpg', NULL, 'твердый', 'вышла', 1, NULL, 1),
(13, 'Особняк с выходом в астрал', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-04-120281-1', NULL, NULL, 2, 6, NULL, 2, 2021, 320, 0.32, '16', 'covers/13.jpg', NULL, 'твердый', 'вышла', 1, NULL, 1),
(14, 'Единственный ребенок', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-04-113678-9', NULL, NULL, 2, 6, NULL, 1, 2021, 352, 0.37, '16', 'covers/14.jpg', 10000, 'твердый', 'вышла', 1, NULL, 0),
(15, 'Дом голосов', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-389-19101-3', NULL, NULL, 2, 6, NULL, 2, 2021, 352, 0.46, '16', 'covers/15.jpg', 3000, 'твердый', 'вышла', 1, NULL, 0),
(16, 'Золушка', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-17-122190-4', NULL, NULL, 3, 4, NULL, 2, 2021, 416, 0.36, '16', 'covers/16.jpg', NULL, 'твердый', 'вышла', 1, NULL, 0),
(17, 'Ковен озера Шамплейн', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-04-112010-8', NULL, NULL, 3, 4, NULL, 2, 2021, 544, 0.45, '18', 'covers/17.jpg', 3000, 'твердый', 'вышла', 1, NULL, 0),
(18, 'Вопрос и ответ', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-04-120667-3', NULL, NULL, 3, 4, NULL, 2, 2021, 480, 0.59, '16', 'covers/18.jpg', 4000, 'твердый', 'вышла', 1, NULL, 1),
(19, 'Институт', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-17-120968-1', NULL, NULL, 3, 4, NULL, 2, 2021, 608, 0.55, '16', 'covers/19.jpg', NULL, 'твердый', 'вышла', 1, NULL, 0),
(20, 'Битва при Коррине', 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio, cumque nihil impedit, quo minus id, quod maxime placeat, facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet, ut et voluptates repudiandae sint  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '978-5-17-133304-1', NULL, NULL, 3, 4, NULL, 2, 2021, 800, 0.64, '16', 'covers/20.jpg', NULL, 'твердый', 'вышла', 1, NULL, 0),
(39, 'Три медведя варят кашу', '', '', '', '', 3, 6, 10, 8, 0, 0, 0, '', '', 0, 'Твёрдый', '', 1, 0, 1),
(40, 'NO translator', '', '', '', '', 1, 1, 1, 1, 0, 0, 0, '', '', 0, 'Твёрдый', '', 1, 0, 1),
(41, 'Твёрдый переплёт', '', '', '', '', 1, 1, 1, 1, 0, 0, 0, '', '', 0, 'Твёрдый', '', 1, 0, 1),
(42, 'Твёрдый переплёт', '', '', '', '', 1, 1, 1, 1, 0, 0, 0, '', '', 0, 'Твёрдый', '', 1, 0, 1),
(43, 'Твёрдый переплёт', '', '', '', '', 1, 1, 1, 1, 0, 0, 0, '', '', 0, 'Твёрдый', '', 1, 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `books_has_authors`
--

CREATE TABLE `books_has_authors` (
  `Books_id_Book` int NOT NULL,
  `Authors_id_Author` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `books_has_authors`
--

INSERT INTO `books_has_authors` (`Books_id_Book`, `Authors_id_Author`) VALUES
(1, 1),
(6, 1),
(40, 1),
(41, 1),
(42, 1),
(43, 1),
(2, 2),
(7, 2),
(3, 3),
(8, 4),
(4, 5),
(5, 6),
(10, 7),
(11, 8),
(39, 8),
(12, 9),
(13, 10),
(14, 11),
(15, 12),
(16, 13),
(17, 14),
(18, 15),
(19, 16),
(20, 17),
(20, 18);

-- --------------------------------------------------------

--
-- Структура таблицы `books_has_translators`
--

CREATE TABLE `books_has_translators` (
  `Books_id_Book` int NOT NULL,
  `Translators_id_Translator` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `books_has_translators`
--

INSERT INTO `books_has_translators` (`Books_id_Book`, `Translators_id_Translator`) VALUES
(1, 1),
(6, 1),
(2, 2),
(3, 3),
(8, 4),
(14, 5),
(20, 6);

-- --------------------------------------------------------

--
-- Структура таблицы `category`
--

CREATE TABLE `category` (
  `id_Category` int NOT NULL,
  `TitleRus` varchar(40) DEFAULT NULL,
  `TitleEng` varchar(40) DEFAULT NULL,
  `CatDescription` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `category`
--

INSERT INTO `category` (`id_Category`, `TitleRus`, `TitleEng`, `CatDescription`) VALUES
(1, 'Фэнтези', 'Fantasy', NULL),
(2, 'Детективы', 'Detective', NULL),
(3, 'Фантастика', 'Fiction', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `cycles`
--

CREATE TABLE `cycles` (
  `id_Cycle` int NOT NULL,
  `CycTitle` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `Quantity` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cycles`
--

INSERT INTO `cycles` (`id_Cycle`, `CycTitle`, `Quantity`) VALUES
(1, 'Стеклянный трон', 8),
(2, 'Охота на Джека-Потрошителя', 4),
(3, 'Алая королева', 5),
(4, 'Мара и Морок', 3),
(5, 'Шолох', 3),
(6, 'Королевство шипов и роз', 6),
(7, 'Небесный народец', 4),
(8, 'Потомки первых', 4),
(9, 'Мистические расследования Джекаби', 4),
(10, 'Воронята', 5);

-- --------------------------------------------------------

--
-- Структура таблицы `formats`
--

CREATE TABLE `formats` (
  `id_Format` int NOT NULL,
  `Width` float DEFAULT NULL,
  `Height` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `formats`
--

INSERT INTO `formats` (`id_Format`, `Width`, `Height`) VALUES
(1, 34, 126),
(2, 130, 205),
(8, 120, 321);

-- --------------------------------------------------------

--
-- Структура таблицы `series`
--

CREATE TABLE `series` (
  `id_Seria` int NOT NULL,
  `SerTitle` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `SerDescription` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `series`
--

INSERT INTO `series` (`id_Seria`, `SerTitle`, `SerDescription`) VALUES
(1, 'Волшебные миры Сары Дж. Маас', NULL),
(2, 'Расследования Керри Манискалко', NULL),
(3, 'Избранное российское фэнтези', NULL),
(4, 'Миры фантастики', NULL),
(5, 'Фэнтезийные зарубежные миры', NULL),
(6, 'Детективные расследования', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

CREATE TABLE `sessions` (
  `id_User` int NOT NULL,
  `SKey` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id_User`, `SKey`) VALUES
(4, '359e153c933f213be7965957798915741c9ee9d745570a119f0eebd20539b214d12ac9c252ff4d03b4f7e7df73e27d638c65ff20bb7ba99f41c993ce1fcc01c3'),
(5, 'c4c5b976ee63dcf501fcb8668df791f0c5baaa3195adb97f21fba61b7649bcbb47be04165cc4e50fd421587aad7659351076025a94e885839f4bea9d7c050a3e'),
(11, '9815f4c5feedc64761c93922b2546eeef9d7c1d3ecd1b4f9c55b7428fde3eaf806dbebe5777be5f46522e830edb9042c05e1cd7e1da3fe731ff9709c31b72950');

-- --------------------------------------------------------

--
-- Структура таблицы `translators`
--

CREATE TABLE `translators` (
  `id_Translator` int NOT NULL,
  `TFullName` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `translators`
--

INSERT INTO `translators` (`id_Translator`, `TFullName`) VALUES
(1, 'Иван Иванов'),
(2, 'Татьяна Ибрагимова'),
(3, 'Валентина Сергеева'),
(4, 'Сергей Самуйлов'),
(5, 'Артем Лисочкин'),
(6, 'Александр Анваер'),
(12, 'Три пять'),
(13, 'Раз два');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id_User` int NOT NULL,
  `UName` varchar(30) NOT NULL,
  `UDate_of_Birth` date DEFAULT NULL,
  `UEmail` varchar(256) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `UPassword` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `USalt` varchar(100) NOT NULL,
  `Admin` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_User`, `UName`, `UDate_of_Birth`, `UEmail`, `UPassword`, `USalt`, `Admin`) VALUES
(4, 'Ирина', '1999-01-06', 'brot@gmail.com', '8bac07174c1025a579fd1f37c76024cce1d0f94e80f48e16af6457131cdc456cd1a6ba28cfac13ad72a88a7af3251c2a8424e630841f0971237b4f3b17d49aa6', '4917621debdd1c9d', 1),
(5, 'Паша', '2021-05-01', 'sosnina.ira16@yandex.ru', '38103c0979bcbff5c6c53e72f2420e74f7a5808d728a8eda1a1f7e7688646ee96fd47510c93d166d9293325b958b305c9935ea65ce67f946a1b34a41a36b056f', '970f1b7655549f4e', 0),
(11, '123123', '0123-03-12', 'a@a.a', '38d72d1e8e78e615618196d761f05acad09b067cc260b4b504b5a79fe68d983f7e3bc1663c176e237f58954ca4d6bf028c9486322f6981ce439ff8064b99769f', '69378d086c08cc9d', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `users_have_books`
--

CREATE TABLE `users_have_books` (
  `Users_id_User` int NOT NULL,
  `Books_id_Book` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users_have_books`
--

INSERT INTO `users_have_books` (`Users_id_User`, `Books_id_Book`) VALUES
(4, 1),
(4, 3),
(4, 12);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id_Author`);

--
-- Индексы таблицы `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id_Book`),
  ADD KEY `Cycles_idx` (`id_Cycle`),
  ADD KEY `Formats` (`id_Format`),
  ADD KEY `Seria` (`id_Seria`),
  ADD KEY `id_Category` (`id_Category`);

--
-- Индексы таблицы `books_has_authors`
--
ALTER TABLE `books_has_authors`
  ADD PRIMARY KEY (`Books_id_Book`,`Authors_id_Author`),
  ADD KEY `fk_Books_has_Authors_Authors1_idx` (`Authors_id_Author`),
  ADD KEY `fk_Books_has_Authors_Books1_idx` (`Books_id_Book`);

--
-- Индексы таблицы `books_has_translators`
--
ALTER TABLE `books_has_translators`
  ADD PRIMARY KEY (`Books_id_Book`,`Translators_id_Translator`),
  ADD KEY `fk_Books_has_Translators_Translators1_idx` (`Translators_id_Translator`),
  ADD KEY `fk_Books_has_Translators_Books1_idx` (`Books_id_Book`);

--
-- Индексы таблицы `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id_Category`);

--
-- Индексы таблицы `cycles`
--
ALTER TABLE `cycles`
  ADD PRIMARY KEY (`id_Cycle`);

--
-- Индексы таблицы `formats`
--
ALTER TABLE `formats`
  ADD PRIMARY KEY (`id_Format`);

--
-- Индексы таблицы `series`
--
ALTER TABLE `series`
  ADD PRIMARY KEY (`id_Seria`);

--
-- Индексы таблицы `sessions`
--
ALTER TABLE `sessions`
  ADD UNIQUE KEY `id_User` (`id_User`,`SKey`) USING BTREE;

--
-- Индексы таблицы `translators`
--
ALTER TABLE `translators`
  ADD PRIMARY KEY (`id_Translator`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_User`);

--
-- Индексы таблицы `users_have_books`
--
ALTER TABLE `users_have_books`
  ADD PRIMARY KEY (`Books_id_Book`,`Users_id_User`) USING BTREE,
  ADD KEY `fk_Users_have_Books_Users1` (`Users_id_User`),
  ADD KEY `fk_Users_have_Books_Books1` (`Books_id_Book`) USING BTREE;

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `authors`
--
ALTER TABLE `authors`
  MODIFY `id_Author` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT для таблицы `books`
--
ALTER TABLE `books`
  MODIFY `id_Book` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT для таблицы `category`
--
ALTER TABLE `category`
  MODIFY `id_Category` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT для таблицы `cycles`
--
ALTER TABLE `cycles`
  MODIFY `id_Cycle` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `formats`
--
ALTER TABLE `formats`
  MODIFY `id_Format` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `series`
--
ALTER TABLE `series`
  MODIFY `id_Seria` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `translators`
--
ALTER TABLE `translators`
  MODIFY `id_Translator` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id_User` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `books_ibfk_1` FOREIGN KEY (`id_Category`) REFERENCES `category` (`id_Category`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `Cycles` FOREIGN KEY (`id_Cycle`) REFERENCES `cycles` (`id_Cycle`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `Formats` FOREIGN KEY (`id_Format`) REFERENCES `formats` (`id_Format`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `Seria` FOREIGN KEY (`id_Seria`) REFERENCES `series` (`id_Seria`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `books_has_authors`
--
ALTER TABLE `books_has_authors`
  ADD CONSTRAINT `fk_Books_has_Authors_Authors1` FOREIGN KEY (`Authors_id_Author`) REFERENCES `authors` (`id_Author`),
  ADD CONSTRAINT `fk_Books_has_Authors_Books1` FOREIGN KEY (`Books_id_Book`) REFERENCES `books` (`id_Book`) ON DELETE CASCADE ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `books_has_translators`
--
ALTER TABLE `books_has_translators`
  ADD CONSTRAINT `fk_Books_has_Translators_Books1` FOREIGN KEY (`Books_id_Book`) REFERENCES `books` (`id_Book`),
  ADD CONSTRAINT `fk_Books_has_Translators_Translators1` FOREIGN KEY (`Translators_id_Translator`) REFERENCES `translators` (`id_Translator`);

--
-- Ограничения внешнего ключа таблицы `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `fk_id_User` FOREIGN KEY (`id_User`) REFERENCES `users` (`id_User`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `users_have_books`
--
ALTER TABLE `users_have_books`
  ADD CONSTRAINT `fk_Users_have_Books_Books1` FOREIGN KEY (`Books_id_Book`) REFERENCES `books` (`id_Book`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_Users_have_Books_Users1` FOREIGN KEY (`Users_id_User`) REFERENCES `users` (`id_User`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
