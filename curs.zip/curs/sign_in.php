<?php 
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"> <!-- Кодировка страницы -->
        <!-- Бибдиотеки BOOTSTRAP и JQuery -->
        <link rel="stylesheet" href="lib/bootstrap-4.2.1/css/bootstrap.css">
        <script src="lib/js/jquery-3.3.1.js"></script>
        <script src="lib/js/popper.min.js"></script>
        <script src="lib/bootstrap-4.2.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css_file.css"> <!-- Мои стили -->
        <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> <!-- Шрифт -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Вход</title>
    </head>
    <body>
        <?php include ('header.php'); ?>
        <div class="main">

        <!-- Шапка страницы -->
        

        <form action="auth.php"  method="post">
            <div style="padding-bottom: 50px;">
                <div class="container">
                    
                    <div class="container form-group card mt-5 p-4 col-md-6 col-6">
                        <h2 class="text-center pb-3">
                            Вход/<a href="registration.php">Регистрация</a>
                        </h2>
                        <div class="" id="reg-form">
                            <?php if ( !empty($_GET['error']) ) {
                                if ($_GET['error'] == 'wrong_credentials') { ?>
                                
                                <div class="alert alert-danger">
                                    Неверный почтовый адрес или пароль
                                </div>
                                
                                <?php } else { ?>
                                    <div class="toast">
                                    Ошибка!
                                    </div>
                                <?php } ?>
                            <?php } ?>

                            <div>
                                <label style="font-size: 25px">E-mail</label>
                                <input type="email" class="form-control" name="email" placeholder="Введите e-mail" required> 
                            </div>

                            <div>
                                <label style="font-size: 25px">Пароль</label>
                                <input type="password" class="form-control" name="password" placeholder="Введите пароль" required> 
                            </div>

                        </div>
                        <div class="mt-4 text-center">
                            <button class="btn btn-light" type="submit" name="action" value="auth" style="font-size: 20px">
                                Войти
                            </button>
                        </div>
                    </div> 
                </div>
            </div>
        </form>
        
        </div>
        
        <!-- Подвал страницы -->
        <?php include ('footer.php'); ?>
        
    </body>
</html>