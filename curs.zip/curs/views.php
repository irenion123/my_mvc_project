<?php

function getBookView($user, $book, $reservedBooks)
{
?>
<div class="col-sm-6 col-md-4 col-lg-3 col-12 pr d-flex flex-column justify-content-between" style="margin-bottom: 30px;">
    <a class="name-prepod" href="view_book.php?book_id=<?= $book["id_Book"] ?>">
    <div class="book-image bg-white" style="background: url('<?= $book['Cover'] ?>'); background-size: contain; background-position: center;"></div>
        <hr style="width: 100%; border: none; background-color: #000; height: 2px;">
        <span><?= $book['Title'] ?></span></br>
        <span class="author_text"><?= $book['AFullName'] ?></span>
    </a>
    <div class="mt-3">
        <?php if (!empty($user)) { ?>
            <?php if (in_array($book['id_Book'], $reservedBooks)) { ?>
            <button class="btn btn-light" onclick="removeReservation('<?= $book["id_Book"] ?>', this)">Убрать</button>
            <?php } else { ?>
            <button class="btn btn-light" onclick="addReservation('<?= $book["id_Book"] ?>', this)">Отложить</button>
            <?php } ?>
        <?php } else { ?>
        <a href="/sign_in.php" class="btn btn-light">Отложить</a>
        <?php } ?>
    </div>
</div>

<?php
    
}

?>

