<?php
session_start();
include_once('database/connection.php');
$conn = new MyConnection();
if (!empty($_SESSION["key"])) {
    $user = $conn->getUserFromSession($_SESSION["key"]);
    //echo "user got!";
} else {
	http_response_code(401);
}



$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'POST') {
	$conn->reserveBook($user['id_User'], $_POST['book_id']);
	echo "ok";
} elseif ($method === 'DELETE') {
	$book_id = preg_replace('/[^0-9]/', '', file_get_contents('php://input'));
	
	$conn->removeBookReservation($user['id_User'], $book_id);
	echo "ok";
} else {
	http_response_code(400);
}

