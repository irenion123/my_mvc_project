<?php 
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include ('database/connection.php'); ?>
        <meta charset="utf-8"> <!-- Кодировка страницы -->
        <!-- Бибдиотеки BOOTSTRAP и JQuery -->
        <link rel="stylesheet" href="lib/bootstrap-4.2.1/css/bootstrap.css">
        <script src="lib/js/jquery-3.3.1.js"></script>
        <script src="lib/js/popper.min.js"></script>
        <script src="lib/bootstrap-4.2.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css_file.css"> <!-- Мои стили -->
        <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> <!-- Шрифт -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Добавить</title>
        <script src="/main.js"></script>
    </head>
    <body>
        <!-- Шапка страницы -->
        <?php include ('header.php'); ?>

        <?php 
        //include ('database/entities.php'); 
        $conn = new MyConnection();
        ?>

        <div class="main">

            <!-- Форма категорий -->
            <form action="add_all.php"  method="post">
                <div class="container form-group card my-5 p-4 shadow-md">
                    <h2 class="text-center pb-3"> Категории </h2>
                    <?php foreach($conn->getCategories() as $i => $category) { ?>

                    <div id="<?=$category['id_Category']?>_category" class="<?php if ($i > 0) { echo 'border-top '; }  ?> d-flex flex-row justify-content-between py-2">
                        <div class="d-flex flex-row">
                            <div class="h4 mr-2"><?=$category['TitleRus']?></div>
                            <div class="h4 text-secondary">@<?=$category['TitleEng']?></div>
                        </div>
                        <div class="btn btn-outline-danger" onclick="deleteCategory('<?=$category['id_Category']?>_category')">Удалить</div>
                    </div>
                    <?php } ?>
                    <h2 class="pt-3"> Добавление категории </h2>
                    <div class="row" id="reg-form">
                        <div class="col-sm">
                            <label style="font-size: 25px">Категория</label>
                            <input type="text" class="form-control" name="category" placeholder="" >
                        </div>
                        <div class="col-sm">
                            <label style="font-size: 25px">Категория англ</label>
                            <input type="text" class="form-control" name="encategory" placeholder="" >
                        </div>
                    </div>
                    <div class="row" id="reg-form">
                        <div class="col-sm">
                            <label style="font-size: 25px">Описание</label>
                            <textarea type="text" class="form-control" name="catdescription" placeholder="" ></textarea>
                        </div>
                    </div>
                    <div class="mt-4 text-center">
                        <button class="btn btn-light" type="submit" name="action" value="add_cat" style="font-size: 20px">
                            Добавить
                        </button>
                    </div>
                </div>
            </form>

            <!-- Форма циклов -->
            <form action="add_all.php"  method="post">
                <div class="container form-group card my-5 p-4 shadow-md">
                    <h2 class="text-center pb-3"> Циклы </h2>
                    <?php foreach($conn->getCycle() as $i => $cycle) { ?>
                    <div id="<?=$cycle['id_Cycle']?>_cycle" class="<?php if ($i > 0) { echo 'border-top '; }  ?> d-flex flex-row justify-content-between py-2">
                        <div class="d-flex flex-row">
                            <div class="h4 mr-2"><?=$cycle['CycTitle']?></div>
                            <div class="h4 text-secondary"><?=$cycle['Quantity']?> кн</div>
                        </div>
                        <div class="btn btn-outline-danger" onclick="deleteCycle('<?=$cycle['id_Cycle']?>_cycle')">Удалить</div>
                    </div>
                    <?php } ?>
                    <h2 class="pt-3"> Добавление цикла </h2>
                    <div class="row" id="reg-form">
                        <div class="col-sm">
                            <label style="font-size: 25px">Авторский цикл</label>
                            <input type="text" class="form-control" name="cycle" placeholder="" >
                        </div>
                        <div class="col-sm">
                            <label style="font-size: 25px">Количество</label>
                            <input type="text" class="form-control" name="quantity" placeholder="" >
                        </div>
                    </div>
                    <div class="mt-4 text-center">
                        <button class="btn btn-light" type="submit" name="action" value="add_cyc" style="font-size: 20px">
                            Добавить
                        </button>
                    </div>
                    
                </div> 
            </form>

            <!-- Форма серий -->
            <form action="add_all.php"  method="post">
                <div class="container form-group card my-5 p-4 shadow-md">
                    <h2 class="text-center pb-3"> Серии </h2>
                    <?php foreach($conn->getSeries() as $i => $series) { ?>
                    <div id="<?=$series['id_Seria']?>_seria" class="<?php if ($i > 0) { echo 'border-top '; }  ?> d-flex flex-row justify-content-between py-2">
                        <div class="d-flex flex-row">
                            <div class="h4 mr-2"><?=$series['SerTitle']?></div>
                        </div>
                        <div class="btn btn-outline-danger" onclick="deleteSeries('<?=$series['id_Seria']?>_seria')">Удалить</div>
                    </div>
                    <?php } ?>
                    <h2 class="pt-3"> Добавление серии </h2>
                    <div class="row" id="reg-form">
                        <div class="col-sm">
                            <label style="font-size: 25px">Название</label>
                            <input type="text" class="form-control" name="seria" placeholder="" >
                        </div>
                    </div>
                    <div class="row" id="reg-form">
                        <div class="col-sm">
                            <label style="font-size: 25px">Описание</label>
                            <textarea type="text" class="form-control" name="serdescription" placeholder="" ></textarea>
                        </div>
                    </div>
                    <div class="mt-4 text-center">
                        <button class="btn btn-light" type="submit" name="action" value="add_seria" style="font-size: 20px">
                            Добавить
                        </button>
                    </div>
                </div> 
            </form>

            <!-- Форма форматов -->
            <form action="add_all.php"  method="post">
                <div class="container form-group card my-5 p-4 shadow-md">
                    <h2 class="text-center pb-3"> Форматы </h2>
                    <?php foreach($conn->getFormats() as $i => $formats) { ?>

                    <div id="<?=$formats['id_Format']?>_format" class="<?php if ($i > 0) { echo 'border-top '; }  ?> d-flex flex-row justify-content-between py-2">
                        <div class="d-flex flex-row">
                            <div class="h4 mr-2"><?=$formats['Width']?>x<?=$formats['Height']?></div>
                        </div>
                        <div class="btn btn-outline-danger btn-outlined" onclick="deleteFormats('<?=$formats['id_Format']?>_format')">Удалить</div>
                    </div>
                    <?php } ?>
                    <h2 class="pt-3"> Добавление формата </h2>
                    <div class="row" id="reg-form">
                        <div class="col-sm">
                            <label style="font-size: 25px">Ширина</label>
                            <input type="text" class="form-control" name="width" placeholder="" >
                        </div>
                        <div class="col-sm">
                            <label style="font-size: 25px">Высота</label>
                            <input type="text" class="form-control" name="height" placeholder="" >
                        </div>
                    </div>
                    <div class="mt-4 text-center">
                        <button class="btn btn-light" type="submit" name="action" value="add_form" style="font-size: 20px">
                            Добавить
                        </button>
                    </div>
                </div> 
            </form>
        </div>
        
        <!-- Подвал страницы -->
        <?php include ('footer.php'); ?>

    </body>
</html>
