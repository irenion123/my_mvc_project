<?php
session_start();

include_once('database/connection.php');

$conn = new MyConnection();

if ($_POST['action'] === 'auth')
{
    $email = $_POST['email'];
    $pass  = $_POST['password'];
    
    if (!$conn->authUser($email, $pass)) 
    {
        header("Location: /sign_in.php?error=wrong_credentials", true, 301);
        exit('Пароль или логин не верный');
    }

    $key = $conn->addSession($email);

    $_SESSION["key"] = $key;
    header("Location: /index.php", true, 301);
    exit('ok');
}

if ($_POST['action'] === 'register')
{
    $name      = $_POST['first_name'];
    $email     = $_POST['email'];
    $pass      = $_POST['password'];
    $pass_conf = $_POST['password_confirmation'];
    $birthDate = $_POST['birth_date'];

    if ($conn->checkEmailTaken($email)) {
        header("Location: /registration.php?error=email_taken", true, 301);
        exit("Email занят");
    }

    if (strcmp($pass, $pass_conf) !== 0) {
        header("Location: /registration.php?error=password_mismatch", true, 301);
        exit("Пароли не совпадают");
    }

    $conn->addUser($name, $email, $pass, $birthDate);

    header("Location: /index.php", true, 301);
    exit('ok');
}


if (!empty($_GET['sign_out']))
{
    unset($_SESSION["key"]);
    header("Location: /index.php", true, 301);
    exit('ok');
}
