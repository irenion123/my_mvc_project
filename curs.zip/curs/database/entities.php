<?php

class Author
{
    protected $properties = [
        "id_Author" => null,
        "AName" => null,
        "ASurname" => null,
        "AOtshestvo" => null,
        "ADate_of_Birth" => null,
        "ADescription" => null,
    ];
}


class Book
{
    protected $properties = [
        "id_Book" => null,
        "Title" => null,
        "ISBN" => null,
        "YDK" => null,
        "BBK" => null,
        "id_Category" => null,
        "id_Seria" => null,
        "id_Cycle" => null,
        "id_Format" => null,
        "Year" => null,
        "Number_of_pages" => null,
        "Weight" => null,
        "Age" => null,
        "Cover" => null,
        "Binding" => null,
        "Status" => null,
        "is_Shown" => null,
        "Number_in_Cycle" => null,
        "is_Best" => null,
    ];
}

class Category
{
    const ID_CATEGORY_FANTASY = 1;
    const ID_CATEGORY_DETECTIVE = 2;
    const ID_CATEGORY_FICTION = 3;
    protected $properties = [
        "id_Category" => null,
        "TitleRus" => null,
        "TitleEng" => null,
        "Description" => null,
    ];
}

class Format
{
    protected $properties = [
        "id_Format" => null,
        "Width" => null,
        "Height" => null,
    ];
}

class Form
{
    protected $properties = [
        "id_Form" => null,
        "FNameall" => null,
        "email" => null,
        "telephone" => null,
        "text" => null,
    ];
}

class Seria
{
    protected $properties = [
        "id_Seria" => null,
        "Name" => null,
        "Description" => null,
    ];
}

class Translator
{
    protected $properties = [
        "id_Translator" => null,
        "TName" => null,
        "TSurname" => null,
        "TOtshestvo" => null,
        "TTeam" => null,
    ];
}


class User
{
    protected $properties = [
        "id_User" => null,
        "UName" => null,
        "USurname" => null,
        "UOtshestvo" => null,
        "UDate_of_Birth" => null,
        "Telephone" => null,
    ];
}

