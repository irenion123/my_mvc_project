<?php

class Book {

	$properties = [
		"id_Book" => null,
		"book_name" => null,
		"book_name" => null,
		"book_name" => null,
		"book_name" => null,
		"book_name" => null,
		"book_name" => null,
	]
}

?>