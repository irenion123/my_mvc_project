<?php
include_once('entities.php');

class MyConnection {

	const SECRET_KEY = "SECRET_KEY";
    const DEBUG = True;

	function __construct() {
		$host ='localhost:3307';
		$database = 'curs';
		$user = 'root';
		$pass = 'root';
		$pdo = "mysql:host=$host;dbname=curs";

		try {
			$this->db = new PDO($pdo, $user, $pass);
		} catch (PDOException $e) {
			die('Подключение не удалось:'.$e->getMessage());
		}
	}

	/**
	 *	Функция для получения всех книг
	 * 	@param $visibility - контролирует значение столбца isShown в таблице Books
	 * 	@param $category - контролирует значение столбца category, чтобы не было ошибок, *	использовать только констатны категории (Entities->Category)
	 */
	function getBooks($visibility = 1, $category = null) : array
	{
		try {
			$sql = "
				SELECT 
				b.*,
				GROUP_CONCAT(a.AFullName SEPARATOR ', ') as AFullName FROM books as b
				JOIN books_has_authors as ba on b.id_Book = ba.Books_id_Book
				JOIN authors as a on a.id_Author = ba.Authors_id_Author
				JOIN category as cat on b.id_Category = cat.id_Category
				WHERE b.is_Shown = $visibility 

			";

			if ($category != null) {
				$sql = $sql . " AND b.id_Category = $category";
			}

			$sql = $sql . " GROUP BY b.id_Book";
			$query = $this->db->prepare($sql);
			$query->execute();

			return $query->fetchAll();
		} catch (\Exception $e) {
			echo $e;
		}
		
	}

    function getCategories(): Array
    {
        try {
            $sql = " SELECT * FROM category ";

            $query = $this->db->prepare($sql);
            $query->execute();

            return $query->fetchAll();
        } catch (\Exception $e) {
            echo $e;
        }
    }

    function getTranslators(): Array
    {
        try {
            $sql = " SELECT * FROM translators ";

            $query = $this->db->prepare($sql);
            $query->execute();

            return $query->fetchAll();
        } catch (\Exception $e) {
            echo $e;
        }
    }

    function getCycle(): Array
    {
        try {
            $sql = " SELECT * FROM cycles ";

            $query = $this->db->prepare($sql);
            $query->execute();

            return $query->fetchAll();
        } catch (\Exception $e) {
            echo $e;
        }
    }

    function getSeries(): Array
    {
        try {
            $sql = " SELECT * FROM series ";

            $query = $this->db->prepare($sql);
            $query->execute();

            return $query->fetchAll();
        } catch (\Exception $e) {
            echo $e;
        }
    }

    function getFormats(): Array
    {
        try {
            $sql = " SELECT * FROM formats ";

            $query = $this->db->prepare($sql);
            $query->execute();

            return $query->fetchAll();
        } catch (\Exception $e) {
            echo $e;
        }
    }

	function getBookByID($id) : array
	{
		try {
			$sql = "
				SELECT 
				b.*, cat.*, cyc.*, ser.*, frmt.*,
				GROUP_CONCAT(tr.TFullName SEPARATOR ', ') as TFullName,
				GROUP_CONCAT(a.AFullName SEPARATOR ', ') as AFullName FROM books as b
				JOIN books_has_authors as ba on b.id_Book = ba.Books_id_Book
				JOIN authors as a on a.id_Author = ba.Authors_id_Author
				LEFT JOIN books_has_translators as bt on b.id_Book = bt.Books_id_Book
            	LEFT JOIN translators as tr on tr.id_Translator = bt.Translators_id_Translator
				JOIN category as cat on b.id_Category = cat.id_Category
				LEFT JOIN cycles as cyc on b.id_Cycle = cyc.id_Cycle
				LEFT JOIN series as ser on b.id_Seria = ser.id_Seria
				LEFT JOIN formats as frmt on b.id_Format = frmt.id_Format
				WHERE b.id_Book = $id
				GROUP BY b.id_Book
			";

			$query = $this->db->prepare($sql);
			$query->execute();

			return $query->fetch();
		} catch (\Exception $e) {
			echo $e;
		}
		
	}

	
	function getVisibleBest() : array
	{
		$sql = "
			SELECT 
				b.*,
    			GROUP_CONCAT(a.AFullName SEPARATOR ', ') as AFullName FROM books as b
	            JOIN books_has_authors as ba on b.id_Book = ba.Books_id_Book
	            JOIN authors as a on a.id_Author = ba.Authors_id_Author	
	            WHERE b.is_Shown = 1 AND b.is_Best = 1
                GROUP BY b.id_Book			
		";

		$query = $this->db->prepare($sql);
		#$query->setFetchMode(PDO::FETCH_CLASS, 'Book');
		$query->execute();

		return $query->fetchAll();
	}

	function getAuthors() : array
	{
		$sql = "
			SELECT * FROM authors as a
		";

		$query = $this->db->prepare($sql);
		#$query->setFetchMode(PDO::FETCH_CLASS, 'Book');
		$query->execute();

		return $query->fetchAll();
	}


	function getAuthorsByID($id) : array
	{
		$sql = "
			SELECT * FROM authors as a
			WHERE a.id_Author = $id
		";

		$query = $this->db->prepare($sql);
		#$query->setFetchMode(PDO::FETCH_CLASS, 'Book');
		$query->execute();

		return $query->fetch();
	}


	function getUserByID($id) : array
	{
		$sql = "
			SELECT us.UName,
	   			   us.UDate_of_Birth,
	   			   us.UEmail
 			FROM users as us
			WHERE us.id_User = $id
		";



		$query = $this->db->prepare($sql);
		#$query->setFetchMode(PDO::FETCH_CLASS, 'Book');
		$query->execute();

		return $query->fetch();
	}

	function checkEmailTaken($email) : bool {
		$sql = " SELECT * FROM users WHERE UEmail='$email'";
		
		$query = $this->db->prepare($sql);
		$query->execute();
		
		return count($query->fetchAll()) > 0;
	}

	function addUser(
		$firstName,
		$email,
		$password,
		$birthDate
	) {
		if (preg_match('/\s/', $firstName)) {
        	// Поле "Имя" содержит пробел
        	$firstName = trim($firstName);
    	    $firstName = explode(" ", $firstName)[0];
	    }

	    // Генерируем соль
	    $salt = bin2hex(random_bytes(8));
	    // Солим пароль
	    $password = $password . $salt;

	    //echo $password;
	    // Хешируем солёный пароль
	    $hashedPass = hash("sha512", $password);

		$sql = " INSERT INTO users 
			(UName, UEmail, UPassword, UDate_of_Birth, USalt)
			VALUES ('$firstName', '$email', '$hashedPass', '$birthDate', '$salt')
		";
		
		$query = $this->db->prepare($sql);
		$query->execute();
	}

	function getUserByEmail($email) 
	{
		$sql = " SELECT * FROM users WHERE UEmail='$email'";
		$query = $this->db->prepare($sql);
		$query->execute();

		$user = $query->fetch();
		return $user;
	}

	function authUser($email, $password) : bool {
		
		$user = $this->getUserByEmail($email);
		if (empty($user)) {
			return false;
		}
		

		$salt = $user['USalt'];
		$dbPass = $user['UPassword'];

		$hashedPass = hash("sha512", $password . $salt);

		// echo '<pre>';
		// echo $dbPass;
		// echo PHP_EOL;
		// echo $hashedPass;
		// echo '</pre>';

		if (strcmp($hashedPass, $dbPass) !== 0) {
			return false;
		}


		return true;

	}

	function getUserFromSession($key) : array
	{
		$sql = " SELECT * FROM users
			WHERE id_User=(SELECT id_User FROM sessions	WHERE SKey='$key')
		";
		
		$query = $this->db->prepare($sql);
		if (!$query->execute()) {
			print_r($query);
		}
		
		$user = $query->fetch();

		return $user;
	}

	function addSession($email) : string
	{
		$user = $this->getUserByEmail($email);
		$sessionKey = hash("sha512", $email . $this::SECRET_KEY);

		$sql = " INSERT INTO sessions (id_User, SKey)
			VALUES ({$user['id_User']}, '$sessionKey')
		";
		
		$query = $this->db->prepare($sql);
		$query->execute();
		return $sessionKey;
	}


	function reserveBook($userId, $bookId)
	{
		$sql = " INSERT INTO users_have_books (Users_id_User, 	Books_id_Book)
			VALUES ($userId, $bookId)
		";
		echo $sql;
		$query = $this->db->prepare($sql);

		$query->execute();

		//print_r($query);
		
	}

	function removeBookReservation($userId, $bookId)
	{
		$sql = "DELETE FROM users_have_books 
			WHERE Users_id_User=$userId AND Books_id_Book=$bookId
		";
		$query = $this->db->prepare($sql);
		$query->execute();
		if (!$query->execute()) {
			print_r($query);
			print_r($this->db->errorInfo());
		}
	}

	function getReservedBooks($user) {
		$sql = "
			SELECT 
			b.*,
			GROUP_CONCAT(a.AFullName SEPARATOR ', ') as AFullName FROM books as b
			JOIN users_have_books as link on link.Books_id_Book = b.id_Book
			JOIN books_has_authors as ba on b.id_Book = ba.Books_id_Book
			JOIN authors as a on a.id_Author = ba.Authors_id_Author
			WHERE link.Users_id_User = {$user['id_User']}
			GROUP BY b.id_Book
		";

		$query = $this->db->prepare($sql);	

		if (!$query->execute()) {
			print_r($query);
			print_r($this->db->errorInfo());
		}

		return $query->fetchAll();
	}

	function addBook(
		$title,
        array $authors,
        array $transl,
        $category,
        $seria,
        $cycle,
        $format,
        $numincycle,
        $cover,
        $binding,
        $isbn,
        $udk,
        $bbk,
        $age,
        $circulation,
        $status,
        $year,
        $numofpag,
        $weight,
        $description,
        $best, 
        $shown
	) {

		$sql = " INSERT INTO books 
                   (
                       Title,
                       BDescription,
                       ISBN,
                       YDK,
                       BBK,
                       Year,
                       id_Category,
                       id_Seria,
                       id_Cycle,
                       id_Format,
                       Number_of_pages,
                       Weight,
                       Age,
                       Cover,
                       Сirculation,
                       Binding,
                       Status,
                       is_Shown,
                       Number_in_Cycle,
                       is_Best
                   )
            VALUES (
                '$title',
                '$description',
                '$isbn',
                '$udk',
                '$bbk',
                $year,
                $category,
                $seria,
                $cycle,
                $format,
                $numofpag,
                $weight,
                '$age',
                '$cover',
                $circulation,
                '$binding',
                '$status',
                $shown,
                $numincycle,
                $best
            )
		";
		
		/* echo $sql; */
		
		$query = $this->db->prepare($sql);

		if (!$query) {
			echo "Query error";
		}
		
        $query->execute();
        $bookId = $this->db->lastInsertId();
        if (empty($bookId)) {
            die("Почему то не вставилась книжка");
        }

        $sql = "
           INSERT INTO books_has_authors
           (Books_id_Book, Authors_id_Author)
           VALUES (:book_id, :author_id)
        ";
        $query = $this->db->prepare($sql);
        if (!$query) echo "Query error";

        foreach ($authors as $authorId) {
            $query->execute([
                ":book_id" => $bookId,
                ":author_id" => $authorId,
            ]);
        }

		/* print_r($this->db->errorInfo()); */
	}


	function addAuthor(
		$afullname,
	    $afoto,
	    $adate,
	    $adescription
	) {

		$sql = " INSERT INTO authors 
			       (AFullName, ADate_of_Birth, ADescription, Foto)
			VALUES ('$afullname', '$adate', '$adescription', '$afoto')
		";
		
		$query = $this->db->prepare($sql);

		if (!$query) {
			echo "Query error";
		}
		
		$query->execute();
		//print_r($this->db->errorInfo());
	}

	function addTrans(
		$tfullname
	) {

		$sql = " INSERT INTO translators
			       (TFullName)
			VALUES ('$tfullname')
		";
		
		$query = $this->db->prepare($sql);

		if (!$query) {
			echo "Query error";
		}
		
		$query->execute();
		//print_r($this->db->errorInfo());
	}


    function deleteCat($id) {

        $sql = " delete from category 
            where id_Category=$id
        ";

        $query = $this->db->prepare($sql);

        if (!$query) {
            echo "Query error";
        }

        $query->execute();
        //print_r($this->db->errorInfo());
    }

    function deleteAuth($id) {

        $sql = " delete from authors 
            where id_Author=$id
        ";

        $query = $this->db->prepare($sql);

        if (!$query) {
            echo "Query error";
        }

        $query->execute();
        //print_r($this->db->errorInfo());
    }

    function deleteTrans($id) {

        $sql = " delete from translators 
            where id_Translator=$id
        ";

        $query = $this->db->prepare($sql);

        if (!$query) {
            echo "Query error";
        }

        $query->execute();
        //print_r($this->db->errorInfo());
    }

	function addCat(
		$category,
    	$encategory,
    	$catdescription
	) {

		$sql = " INSERT INTO category 
			       (TitleRus, TitleEng, CatDescription)
			VALUES ('$category', '$encategory', '$catdescription')
		";
		
		$query = $this->db->prepare($sql);

		if (!$query) {
			echo "Query error";
		}
		
		$query->execute();
		//print_r($this->db->errorInfo());
	}

	
	function addCyc(
		$cycle,
    	$quantity
	) {

		$sql = " INSERT INTO cycles 
			       (CycTitle, Quantity)
			VALUES ('$cycle', $quantity)
		";
		
		
		$query = $this->db->prepare($sql);

		if (!$query) {
			echo "Query error";
		}
		
		$query->execute();
		//print_r($this->db->errorInfo());
	}


	function deleteCyc($id) {

        $sql = " delete from cycles
            where id_Cycle=$id
        ";

        $query = $this->db->prepare($sql);

        if (!$query && $this->DEBUG) {
            echo "Query error";
        }
        $query->execute();

        if ($this->DEBUG) {
            print_r($this->db->errorInfo());
        }
    }



	function addSeria(
		$seria,
    	$serdescription
	) {

		$sql = " INSERT INTO series 
			       (SerTitle, SerDescription)
			VALUES ('$seria', '$serdescription')
		";
		
		
		$query = $this->db->prepare($sql);

		if (!$query) {
			echo "Query error";
		}
		
		$query->execute();
		//print_r($this->db->errorInfo());
	}


	function deleteSer($id) {

        $sql = " delete from series 
            where id_Seria=$id
        ";

        $query = $this->db->prepare($sql);

        if (!$query && $this->DEBUG) {
            echo "Query error";
        }
        $query->execute();

        if (!$this->DEBUG) {
            print_r($this->db->errorInfo());
        }
    }



	function addFormat($width, $height) {

		$sql = " INSERT INTO formats 
			       (Width, Height)
			VALUES ($width, $height)
		";
		
		
		$query = $this->db->prepare($sql);

		if (!$query) {
			echo "Query error";
		}
		
		$query->execute();
		//print_r($this->db->errorInfo());
	}


	function deleteForm($id) {

        $sql = " delete from formats 
            where id_Format=$id
        ";

        $query = $this->db->prepare($sql);

        if (!$query) {
            echo "Query error";
        }

        $query->execute();
        //print_r($this->db->errorInfo());
    }


}
