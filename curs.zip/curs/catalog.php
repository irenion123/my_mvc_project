<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <?php include ('database/connection.php'); ?>
    <meta charset="utf-8"> <!-- Кодировка страницы -->
    <!-- Бибдиотеки BOOTSTRAP и JQuery -->
    <link rel="stylesheet" href="lib/bootstrap-4.2.1/css/bootstrap.css">
    <script src="lib/js/jquery-3.3.1.js"></script>
    <script src="lib/js/popper.min.js"></script>
    <script src="lib/bootstrap-4.2.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/css_file.css"> <!-- Мои стили -->
    <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> <!-- Шрифт -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="/main.js"></script>
    <title>Каталог</title>
</head>
<body>
    <?php include ('header.php'); ?>
    <?php 
    include_once ('database/entities.php'); 
    $conn = new MyConnection();
    ?>

    <div class="main">
        <!-- Перечень курсов -->
        <div id="kursi" class="container mb-4 mt-4">


            <h1><span class="letter">Ф</span>энтези.</h1></br>
            <div class="row" style="text-align: left;">
                <?php foreach ($conn->getBooks(1, Category::ID_CATEGORY_FANTASY) as $book) {
                    getBookView($user, $book, $reservedBooks);
                } ?>
            </div>


            <h1><span class="letter">Д</span>етективы.</h1></br>
            <div class="row" style="text-align: left;">
                <?php foreach ($conn->getBooks(1, Category::ID_CATEGORY_DETECTIVE) as $book) {
                    getBookView($user, $book, $reservedBooks);
                } ?>
            </div>


            <h1><span class="letter">Ф</span>антастика.</h1></br>
            <div class="row" style="text-align: left;">
                <?php foreach ($conn->getBooks(1, Category::ID_CATEGORY_FICTION) as $book) {
                    getBookView($user, $book, $reservedBooks);
                } ?>
            </div>
        </div>
    </div>

<!-- Подвал страницы -->
<?php include ('footer.php'); ?>

</body>
</html>
