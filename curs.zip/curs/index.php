<?php 
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include ('database/connection.php'); ?>
        <meta charset="utf-8"> <!-- Кодировка страницы -->
        <link rel="stylesheet" href="css/css_file.css"> <!-- Мои стили -->
        <!-- Бибдиотеки BOOTSTRAP и JQuery -->
        <link rel="stylesheet" href="lib/bootstrap-4.2.1/css/bootstrap.css">
        <script src="lib/js/jquery-3.3.1.js"></script>
        <script src="lib/js/popper.min.js"></script>
        <script src="lib/bootstrap-4.2.1/js/bootstrap.min.js"></script>
        
        <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> <!-- Шрифт -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Сайт издательства</title>
        <script src="/main.js"></script>
    </head>    
    
    <body>
        <?php include ('header.php'); ?>
        
        <?php 
        //include ('database/entities.php'); 
        $conn = new MyConnection();
        ?>

        <div class="main">

            <div class="container mb-4 mt-4">
                 <h1><span class="letter">Ч</span>итай. <span class="letter">Л</span>юби. <span class="letter">Р</span>азвивайся.</h1></br>
            <!-- Слайдер -->
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">

                        <div class="carousel-item active">
                            <img src="slider/1.jpg" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="slider/2.jpg" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="slider/3.jpg" class="d-block w-100" alt="...">
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
            <!-- Курсы -->
            <div class="container mb-4 mt-4">
                        <?php
                        /*
                        echo "<pre>";
                        print_r($conn->getVisibleBest());
                        echo "</pre>";
                        */
                        ?>
                <h1><span class="letter">Н</span>аши бестселлеры.</h1></br>
                <div class="row" style="text-align: left;">
                    
                    <!-- Отсуда -->
                    <?php foreach ($conn->getVisibleBest() as $book) {
                        getBookView($user, $book, $reservedBooks);
                    } ?>
                    <!-- До суда -->
                </div>
            </div>
        </div>

             <div style="padding-bottom: 20px;">
                <div class="container mt-4" id="cont">
                    <div class="row align-items-center" style="text-align: center;">    
                                                <!-- Контактные данные -->
                        <div class="col-lg-6 col-12 align-middle" style="text-align: left;">
                            <div class="contel">
                                <p><span class="letter">У</span>знавай </br> первым о </br> новых книгах</p>
                                <p class="author_text">Все новинки, выпускаемые издательством, Вы сможете увидеть на нашем сайте. Мы будем писать вам раз в месяц о новинках в нашем магазине.</p>
                            </div>
                        </div> 


                        <!-- Карта -->
                        <div class="col-lg-6 col-12 align-middle"><img src="slider/biblioteka.png" width="550" alt="альтернативный текст"></div>

                    </div>
                </div>
            </div> 






        
        <!-- Подвал страницы -->
        <?php include ('footer.php'); ?>
    
    </body>
</html>

