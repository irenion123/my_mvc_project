function addReservation(bookId, button) {
    $.ajax({
        url: "/reserve.php",
        method: "post",
        data: {
            'book_id': bookId
        },
        success: function (data) {
            $(button).text('Убрать');
            $(button).click(function() {removeReservation(bookId, button)});
        },
        error: function(jqXHR, textStatus, errorThrown) {
            if (jqXHR.status == 401) {
                window.location.href = "/sign_in.php";
                return
            }
            window.location.href = "/";
            
        }
    });
}

function removeReservation(bookId, button, remove = false) {
    $.ajax({
        url: "/reserve.php",
        method: "delete",
        data: {
            'book_id': bookId
        },
        success: function (data) {
            if (remove) {
                $('#'+bookId).remove();
            } else {
                $(button).text('Отложить');
            }
            $(button).click(function() {addReservation(bookId, button)});
        },
        error: function(jqXHR, textStatus, errorThrown) {
            if (jqXHR.status == 401) {
                window.location.href = "/sign_in.php";
                return
            }
            window.location.href = "/";
            
        }
    });
}

function deleteCategory(id) {
    $.ajax({
        url: "/add_all.php",
        method: "post",
        data: {
            'action': 'delete_category',
            'category_id': id
        },
        success: function (data) {
            console.log(data);
            $('#'+id).remove();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(errorThrown);
            if (jqXHR.status == 401) {
                window.location.href = "/sign_in.php";
                return
            }
            window.location.href = "/";

        }
    });
}

function deleteAuthor(id) {
    $.ajax({
        url: "/add_all.php",
        method: "post",
        data: {
            'action': 'delete_author',
            'author_id': id
        },
        success: function (data) {
            console.log(data);
            $('#'+id).remove();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(errorThrown);
            if (jqXHR.status == 401) {
                window.location.href = "/sign_in.php";
                return
            }
            window.location.href = "/";

        }
    });
}


function deleteTranslator(id) {
    $.ajax({
        url: "/add_all.php",
        method: "post",
        data: {
            'action': 'delete_translator',
            'translator_id': id
        },
        success: function (data) {
            console.log(data);
            $('#'+id).remove();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(errorThrown);
            if (jqXHR.status == 401) {
                window.location.href = "/sign_in.php";
                return
            }
            window.location.href = "/";

        }
    });
}




function deleteCycle(id) {
    $.ajax({
        url: "/add_all.php",
        method: "post",
        data: {
            'action': 'delete_cycle',
            'cycle_id': id
        },
        success: function (data) {
            console.log(data);
            $('#'+id).remove();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(errorThrown);
            if (jqXHR.status == 401) {
                window.location.href = "/sign_in.php";
                return
            }
            window.location.href = "/";

        }
    });
}



function deleteSeries(id) {
    $.ajax({
        url: "/add_all.php",
        method: "post",
        data: {
            'action': 'delete_series',
            'series_id': id
        },
        success: function (data) {
            console.log(data);
            $('#'+id).remove();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(errorThrown);
            if (jqXHR.status == 401) {
                window.location.href = "/sign_in.php";
                return
            }
            window.location.href = "/";

        }
    });
}


function deleteFormats(id) {
    $.ajax({
        url: "/add_all.php",
        method: "post",
        data: {
            'action': 'delete_formats',
            'formats_id': id
        },
        success: function (data) {
            console.log(data);
            $('#'+id).remove();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(errorThrown);
            if (jqXHR.status == 401) {
                window.location.href = "/sign_in.php";
                return
            }
            window.location.href = "/";

        }
    });
}
