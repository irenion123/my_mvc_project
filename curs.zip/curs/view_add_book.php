<?php 
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include ('database/connection.php'); ?>
        <meta charset="utf-8"> <!-- Кодировка страницы -->
        <!-- Бибдиотеки BOOTSTRAP и JQuery -->
        <link rel="stylesheet" href="lib/bootstrap-4.2.1/css/bootstrap.css">
        <script src="lib/js/jquery-3.3.1.js"></script>
        <script src="lib/js/popper.min.js"></script>
        <script src="lib/bootstrap-4.2.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css_file.css"> <!-- Мои стили -->
        <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> <!-- Шрифт -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Добавить книгу</title>
    </head>
    <body>
        <?php include ('header.php'); ?>

        <?php 
        //include ('database/entities.php'); 
        $conn = new MyConnection();
        ?>

        <div class="main">
            <form action="add_all.php"  method="post">
                <div style="padding-bottom: 50px;">
                    <div class="container">

                        <div class="container form-group card mt-5 p-4">
                            <h2 class="text-center pb-3">
                                Добавление книги
                            </h2>
                            <div class="row" id="reg-form">
                                <div class="col-sm">
                                    <label style="font-size: 25px">Название</label>
                                    <input type="text" class="form-control" name="title" placeholder="" >
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm">
                                    <label style="font-size: 25px">
                                        Автор<div class="btn ml-2 p-2 btn-outline-primary" onClick="{$('#author-for-copy').clone().removeAttr('id').insertAfter('#author-for-copy')}">+</div>
                                    </label>
                                    <select class="form-control" name="authors_id[]" id="author-for-copy">
                                        <?php foreach ($conn->getAuthors() as $auth) { ?>
                                        <option name="" value="<?=$auth['id_Author']?>"><?=$auth['AFullName'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm">
                                    <label style="font-size: 25px">
                                        Переводчик<div class="btn ml-2 p-2 btn-outline-primary" onClick="{$('#translator-for-copy').clone().removeAttr('id').insertAfter('#translator-for-copy')}">+</div>
                                    </label>
                                    <select class="form-control" name="translators_id[]" id="translator-for-copy">
                                        <option name="" value="0">Отсутствует</option>
                                        <?php foreach ($conn->getTranslators() as $translator) { ?>
                                        <option name="" value="<?=$translator['id_Translator']?>"><?=$translator['TFullName'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row" id="reg-form">
                                <div class="col-sm">
                                    <label style="font-size: 25px">Категория</label>
                                    <select class="form-control" name="category_id">
                                        <?php foreach ($conn->getCategories() as $cat) { ?>
                                        <option name="" value="<?=$cat['id_Category']?>"><?=$cat['TitleRus'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="col-sm">
                                    <label style="font-size: 25px">Издательская серия</label>
                                    <select class="form-control" name="series_id">
                                        <?php foreach ($conn->getSeries() as $ser) { ?>
                                        <option name="" value="<?=$ser['id_Seria']?>"><?=$ser['SerTitle'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row" id="reg-form">
                                <div class="col-sm">
                                    <label style="font-size: 25px">Авторский цикл</label>
                                    <select class="form-control" name="cycle_id">
                                        <?php foreach ($conn->getCycle() as $cyc) { ?>
                                        <option name="" value="<?=$cyc['id_Cycle']?>"><?=$cyc['CycTitle'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="col-sm">
                                    <label style="font-size: 25px">Номер в цикле</label>
                                    <input type="text" class="form-control" name="numincycle" placeholder="" >
                                </div>
                            </div>
                            <div class="row" id="reg-form">
                                <div class="col-sm">
                                    <label style="font-size: 25px">Путь к обложке</label>
                                    <input type="text" class="form-control" name="cover" placeholder="" >
                                </div>
                                <div class="col-sm">
                                    <label style="font-size: 25px">Переплет</label>
                                    <select class="form-control" name="binding">
                                        <?php foreach (['Твёрдый', 'Мягкий'] as $binding) { ?>
                                        <option value="<?=$binding?>"><?=$binding?></option>
                                        <?php } ?>
                                    </select>
                                </div> 
                            </div>
                            <div class="row" id="reg-form">
                                <div class="col-sm">
                                    <label style="font-size: 25px">ISBN</label>
                                    <input type="text" class="form-control" name="isbn" placeholder="" >
                                </div>
                                <div class="col-sm">
                                    <label style="font-size: 25px">УДК</label>
                                    <input type="text" class="form-control" name="udk" placeholder="" >
                                </div>
                                <div class="col-sm">
                                    <label style="font-size: 25px">ББК</label>
                                    <input type="text" class="form-control" name="bbk" placeholder="" >
                                </div>
                            </div>
                            <div class="row" id="reg-form">
                                <div class="col-sm">
                                    <label style="font-size: 25px">Возраст</label>
                                    <input type="text" class="form-control" name="age" placeholder="" >
                                </div>
                                <div class="col-sm">
                                    <label style="font-size: 25px">Общий тираж</label>
                                    <input type="text" class="form-control" name="circulation" placeholder="" >
                                </div>
                                <div class="col-sm">
                                    <label style="font-size: 25px">Статус</label>
                                    <input type="text" class="form-control" name="status" placeholder="" >
                                </div>
                                
                            </div>
                            <div class="row" id="reg-form">
                                <div class="col-sm">
                                    <label style="font-size: 25px">Формат</label>
                                    <select class="form-control" name="formats_id">
                                        <?php foreach ($conn->getFormats() as $form) { ?>
                                        <option name="" value="<?=$form['id_Format']?>"><?=$form['Width'] ?>x<?=$form['Height'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="col-sm">
                                    <label style="font-size: 25px">Год выпуска</label>
                                    <input type="text" class="form-control" name="year" placeholder="" >
                                </div>
                                <div class="col-sm">
                                    <label style="font-size: 25px">Кол-во страниц</label>
                                    <input type="text" class="form-control" name="numofpag" placeholder="" >
                                </div>
                                <div class="col-sm">
                                    <label style="font-size: 25px">Вес</label>
                                    <input type="text" class="form-control" name="weight" placeholder="" >
                                </div>
                            </div>
                            <div class="row" id="reg-form">
                                <div class="col-sm">
                                    <label style="font-size: 25px">Аннотация</label>
                                    <textarea type="text" class="form-control" name="bdescription" placeholder="" ></textarea>
                                </div>
                            </div>
                            <div class="row" id="reg-form">
                                <div class="col-sm">
                                    <div class="form-check py-3">
                                        <input style="height: 20px; width: 20px;" name="best" class="form-check-input" type="checkbox" id="bestCheck">
                                        <label style="font-size: 25px" class="pl-3 form-check-label" for="bestCheck">Бестселлер</label>
                                    </div>
                                </div>
                                <div class="col-sm">
                                    <div class="form-check py-3">
                                        <input style="height: 20px; width: 20px;" name="shown" class="form-check-input" type="checkbox" id="shownCheck">
                                        <label style="font-size: 25px" class="pl-3 form-check-label" for="shownCheck">Отображать</label>
                                    </div>
                                </div>
                            </div>

                            <div class="mt-4 text-center">
                                <button class="btn btn-light" type="submit" name="action" value="add_book" style="font-size: 20px">
                                    Добавить
                                </button>
                            </div>
                            
                        </div> 
                    </div>
                </div>
            </form>



        </div>
        
        <!-- Подвал страницы -->
        <?php include ('footer.php'); ?>

    </body>
</html>
