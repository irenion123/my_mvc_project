<?php 
include_once('database/connection.php');
include_once('views.php');
$conn = new MyConnection();
if (!empty($_SESSION["key"])) {
    $user = $conn->getUserFromSession($_SESSION["key"]);     
    $reservedBooks = $conn->getReservedBooks($user);
    $reservedBooks = array_map(function ($a) { return $a['id_Book']; }, $reservedBooks);
    //print_r($reservedBooks);                     
}


?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"> <!-- Кодировка страницы -->
        <!-- Бибдиотеки BOOTSTRAP и JQuery -->
        <link rel="stylesheet" href="lib/bootstrap-4.2.1/css/bootstrap.css">
        <script src="lib/js/jquery-3.3.1.js"></script>
        <script src="lib/js/popper.min.js"></script>
        <script src="lib/bootstrap-4.2.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css_file.css"> <!-- Мои стили -->
        <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> <!-- Шрифт -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
    <style>
        @media (min-width: 768px) {
            .navbar-container {
                position: sticky;
                top: 0;
                overflow-y: auto;
                height: 100vh;
            }
        }
    </style>

    <body class="glav">     
        <!-- Шапка страницы -->
        <header id="header">
            <nav class="navbar navbar-expand-lg navbar-light">
                <!-- Логотип -->
                <a class="navbar-brand" href="index.php">
                    <img class="logo2" src="img/logo.png" style="width: 100px; margin: 0px; border: 0px">
                </a>    
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar1" aria-controls="navbar1" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="col collapse navbar-collapse text-center" id="navbar1">
                    <!-- Меню -->
                    <ul class="navbar-nav mr-auto hr">
                        <li class="lnk-item p-0">
                            <a class="lnk-link px-2" href="index.php">Главная</a>
                        </li>
                        <li class="lnk-item p-0">
                            <a class="lnk-link px-2" href="catalog.php">Каталог</a>
                        </li>
                        <li class="lnk-item p-0">
                            <a class="lnk-link px-2" href="authors.php">Авторы</a>
                        </li>
                        <li class="lnk-item p-0">
                            <a class="lnk-link px-2" href="cont.php">Контакты</a>
                        </li>

                        <?php if (!empty($user) && $user['Admin'] == 1) { ?>
                        <li class="dropdown">
                            <a class="dropdown-toggle lnk-link px-2"
                               href="#"
                               id="asortiDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Администрирование</a>
                            <div class="dropdown-menu" aria-labelledby="asortiDropdown">
                                    <a class="dropdown-item" href="view_add_book.php">Добавить книгу</a>
                                    <a class="dropdown-item" href="view_add_author_transl.php">Добавить автора/переводчика</a>
                                    <a class="dropdown-item" href="view_add_cat_cyc_seria_form.php">Добавить категорию/цикл/серию/формат</a>
                            </div>

                        </li>
                        <?php } ?>
                        
                    </ul>

                    
                    <div>
                        <?php if (!empty($user)) { ?>
                        <a class="lnk-link px-2" href="profile.php">Профиль</a>
                        <?php } else { ?>
                        <a class="lnk-link px-2" href="sign_in.php" style="">Вход/Регистрация</a>
                        <?php } ?>
                        
                    </div>
                </div>
            </nav>       
        </header>
    </body>
</html>

 
