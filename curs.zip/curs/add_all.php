<?php
session_start();

include_once('database/connection.php');

$conn = new MyConnection();
$user = $conn->getUserFromSession($_SESSION["key"]);     



if ($user['Admin'] != 1 ) {
    http_response_code(401);
}

if ($_POST['action'] === 'add_book')
{
    // "Cтрока" ?: "Значение которое использовать если строка пуста"
    $title          = $_POST['title'];
    $authors_id     = $_POST['authors_id'];
    $translators_id = $_POST['translators_id'];
    $category       = $_POST['category_id'];
    $seria          = $_POST['series_id'];
    $cycle          = $_POST['cycle_id'];
    $format         = $_POST['formats_id'];
    $numincycle     = $_POST['numincycle'] ?: 0;
    $cover          = $_POST['cover'];
    $binding        = $_POST['binding'];
    $isbn           = $_POST['isbn'];
    $udk            = $_POST['udk'];
    $bbk            = $_POST['bbk'];
    $age            = $_POST['age'];
    $circulation    = $_POST['circulation'] ?: 0;
    $status         = $_POST['status'];
    $year           = $_POST['year'] ?: 0;
    $numofpag       = $_POST['numofpag'] ?: 0;
    $weight         = $_POST['weight'] ?: 0;
    $bdescription   = $_POST['bdescription'];
    $best           = $_POST['best'] ? 1 : 0;
    $shown          = $_POST['shown'] ? 1 : 0;

    /*
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";
     */

    $conn->addBook(
        $title,
        $authors_id,
        $translators_id,
        $category,
        $seria,
        $cycle,
        $format,
        $numincycle,
        $cover,
        $binding,
        $isbn,
        $udk,
        $bbk,
        $age,
        $circulation,
        $status,
        $year,
        $numofpag,
        $weight,
        $bdescription,
        $best, 
        $shown
    );

    header("Location: /view_add_book.php", true, 301);
    exit('ok');
}


if ($_POST['action'] === 'add_author')
{
    // "Cтрока" ?: "Значение которое использовать если строка пуста"
    $afullname    = $_POST['afullname'];
    $afoto        = $_POST['afoto'] ?: 'fotos/no_foto.jpg';
    $adate        = $_POST['adate'];
    $adescription = $_POST['adescription'];

    $conn->addAuthor(
        $afullname,
        $afoto,
        $adate,
        $adescription
    );

    header("Location: /view_add_author_transl.php", true, 301);
    exit('ok');
}


if ($_POST['action'] === 'add_trans')
{
    // "Cтрока" ?: "Значение которое использовать если строка пуста"
    $tfullname    = $_POST['tfullname'];

    $conn->addTrans(
    $tfullname);

    header("Location: /view_add_author_transl.php", true, 301);
    exit('ok');
}



if ($_POST['action'] === 'add_cat')
{
    // "Cтрока" ?: "Значение которое использовать если строка пуста"
    $category       = $_POST['category'];
    $encategory     = $_POST['encategory'];
    $catdescription = $_POST['catdescription'];

    $conn->addCat(
        $category,
        $encategory,
        $catdescription
    );

    header("Location: /view_add_cat_cyc_seria_form.php", true, 301);
    exit('ok');
}

if ($_POST['action'] === 'delete_category')
{
    // "Cтрока" ?: "Значение которое использовать если строка пуста"
    $id = $_POST['category_id'];
    $id = preg_replace('/[_A-z]/', '', $id);
    $conn->deleteCat($id);
    exit('ok');
}

if ($_POST['action'] === 'delete_author')
{
    // "Cтрока" ?: "Значение которое использовать если строка пуста"
    $id = $_POST['author_id'];
    $id = preg_replace('/[_A-z]/', '', $id);
    $conn->deleteAuth($id);
    exit('ok');
}

if ($_POST['action'] === 'delete_translator')
{
    // "Cтрока" ?: "Значение которое использовать если строка пуста"
    $id = $_POST['translator_id'];
    $id = preg_replace('/[_A-z]/', '', $id);
    $conn->deleteTrans($id);
    exit('ok');
}









if ($_POST['action'] === 'add_cyc')
{
    // "Cтрока" ?: "Значение которое использовать если строка пуста"
    $cycle        = $_POST['cycle'];
    $quantity     = $_POST['quantity'];

    $conn->addCyc(
    $cycle,
    $quantity);

    header("Location: /view_add_cat_cyc_seria_form.php", true, 301);
    exit('ok');
}



if ($_POST['action'] === 'delete_cycle')
{
    // "Cтрока" ?: "Значение которое использовать если строка пуста"
    $id = $_POST['cycle_id'];
    $id = preg_replace('/[_A-z]/', '', $id);
    $conn->deleteCyc($id);
    exit('ok');
}


if ($_POST['action'] === 'add_seria')
{
    // "Cтрока" ?: "Значение которое использовать если строка пуста"
    $seria          = $_POST['seria'];
    $serdescription = $_POST['serdescription'];

    $conn->addSeria(
        $seria,
        $serdescription
    );

    header("Location: /view_add_cat_cyc_seria_form.php", true, 301);
    exit('ok');
}



if ($_POST['action'] === 'delete_series')
{
    // "Cтрока" ?: "Значение которое использовать если строка пуста"
    $id = $_POST['series_id'];
    $id = preg_replace('/[_A-z]/', '', $id);
    $conn->deleteSer($id);
    exit('ok');
}



if ($_POST['action'] === 'add_form')
{
    // "Cтрока" ?: "Значение которое использовать если строка пуста"
    $width   = $_POST['width'];
    $height  = $_POST['height'];

    $conn->addFormat(
    $width,
    $height);

    header("Location: /view_add_cat_cyc_seria_form.php", true, 301);
    exit('ok');
}



if ($_POST['action'] === 'delete_formats')
{
    // "Cтрока" ?: "Значение которое использовать если строка пуста"
    $id = $_POST['formats_id'];
    $id = preg_replace('/[_A-z]/', '', $id);
    $conn->deleteForm($id);
    exit('ok');
}
