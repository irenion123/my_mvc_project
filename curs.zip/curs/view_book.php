<?php 
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include ('database/connection.php'); ?>
        <meta charset="utf-8"> <!-- Кодировка страницы -->
        <!-- Бибдиотеки BOOTSTRAP и JQuery -->
        <link rel="stylesheet" href="lib/bootstrap-4.2.1/css/bootstrap.css">
        <script src="lib/js/jquery-3.3.1.js"></script>
        <script src="lib/js/popper.min.js"></script>
        <script src="lib/bootstrap-4.2.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css_file.css"> <!-- Мои стили -->
        <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> <!-- Шрифт -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="/main.js"></script>

        <title>Книга</title>
    </head>
    <body>

        <?php include ('header.php');?>
        <?php 
        //include ('database/entities.php'); 
        $conn = new MyConnection();
        $book = $conn->getBookByID($_GET["book_id"]);
        if (!empty($user)) {
            $reservedBooks = $conn->getReservedBooks($user);
            $reservedBooks = array_map(function ($a) { return $a['id_Book']; }, $reservedBooks);
        }
        
        ?>


        <div class=main>

            <!-- Шапка страницы -->
            
            </br>

            <div class="container">
                <div class="row">
                    <!-- Картинка -->
                    <div class="col-lg-6 col-12">
                    <?php if (!empty($book)) { ?>
                        <div class="book-image" style="background: url('<?= $book['Cover'] ?>'); background-size: contain; background-position: center;">
                        </div>
                        <div class="mt-2 text-center">
                            <div class="btnmar">
                                <?php if (!empty($user)) { ?>
                                    <?php if (in_array($book['id_Book'], $reservedBooks)) { ?>
                                        <button class="btn btn-light pl-5 pr-5 mt-3" onclick="removeReservation('<?= $book["id_Book"] ?>', this)">Убрать</button>
                                    <?php } else { ?>
                                        <button class="btn btn-light pl-5 pr-5 mt-3" onclick="addReservation('<?= $book["id_Book"] ?>', this)">Отложить</button>
                                    <?php } ?>
                                <?php } else { ?>
                                    <a href="/sign_in.php" class="btn btn-light">Отложить</a>
                                <?php } ?>

                            </div>
                        </div>
                        
                    </div>  
                    <!-- Описание массажа -->
                    <div class="col-lg-6 col-12 name-prepod mt-3 mb-3">
                        <?php if (!empty($book['Title'])) {?> <p style="font-size: 30px;">Название: <?= $book['Title']?><br></p> <?php } ?>
                        <?php if (!empty($book['AFullName'])) {?> <p>Автор(ы): <?= $book['AFullName']?><br></p> <?php } ?>
                        <p align="center">Аннотация:<br></p>
                            <?php if (!empty($book['BDescription'])) {?> <p class="indent" style="font-size:16px;"><?= $book['BDescription']?>  
                            </p><?php } ?>
                        <p align="center">Характеристики:<br></p>
                        <div class="indent" style="font-size:20px;">

                            <?php if (!empty($book['TFullName'])) {?> <p>Переводчик(и): <?= $book['TFullName']?>  </p> <?php } ?>
                            <?php if (!empty($book['ISBN'])) {?> <p>ISBN: <?= $book['ISBN']?>  </p> <?php } ?>
                            <?php if (!empty($book['YDK'])) {?> <p>УДК: <?= $book['YDK']?>  </p> <?php } ?>
                            <?php if (!empty($book['BBK'])) {?> <p>ББК: <?= $book['BBK']?></p> <?php } ?>
                            <?php if (!empty($book['TitleRus'])) {?> <p>Категория: <?= $book['TitleRus']?></p> <?php } ?>
                            <?php if (!empty($book['SerTitle'])) {?> <p>Издательская серия: <?= $book['SerTitle']?></p> <?php } ?>
                            <?php if (!empty($book['CycTitle'])) {?> <p>Цикл: <?= $book['CycTitle']?></p> <?php } ?>
                            <?php if (!empty($book['CycTitle'])&&!empty($book['Number_in_Cycle'])) {?> <p>Номер в цикле: <?= $book['Number_in_Cycle']?></p> <?php } ?>
                            <?php if (!empty($book['Year'])) {?> <p>Год выпуска: <?= $book['Year']?></p> <?php } ?>
                            <?php if (!empty($book['Width'])&&!empty($book['Height'])) {?> <p>Формат: <?= $book['Width']?>x<?= $book['Height']?></p> <?php } ?>
                            <?php if (!empty($book['Number_of_pages'])) {?> <p>Кол-во страниц: <?= $book['Number_of_pages']?></p> <?php } ?>
                            <?php if (!empty($book['Weight'])) {?> <p>Вес: <?= $book['Weight']?></p> <?php } ?>
                            <?php if (!empty($book['Age'])) {?> <p>Возрастное ограничение: <?= $book['Age']?>+</p> <?php } ?>
                            <?php if (!empty($book['Сirculation'])) {?> <p>Общий тираж: <?= $book['Сirculation']?>  </p> <?php } ?>
                            <?php if (!empty($book['Status'])) {?> <p>Статус: <?= $book['Status']?>  </p> <?php } ?>
                        </div>
                        
                    <?php } ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Подвал страницы -->
        <?php include ('footer.php'); ?>

    </body>
</html>
