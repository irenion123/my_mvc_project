<?php 
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include ('database/connection.php'); ?>
        <meta charset="utf-8"> <!-- Кодировка страницы -->
        <!-- Бибдиотеки BOOTSTRAP и JQuery -->
        <link rel="stylesheet" href="lib/bootstrap-4.2.1/css/bootstrap.css">
        <script src="lib/js/jquery-3.3.1.js"></script>
        <script src="lib/js/popper.min.js"></script>
        <script src="lib/bootstrap-4.2.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css_file.css"> <!-- Мои стили -->
        <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> <!-- Шрифт -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Автор</title>
    </head>
    
    <body>
        <?php include ('header.php'); ?>
        <?php 
        //include ('database/entities.php'); 
        $conn = new MyConnection();
        $author = $conn->getAuthorsByID($_GET["author_id"]);
        
        ?>
        <!-- Контентная часть -->
        <div class="main">

            <!-- Шапка страницы -->
    

            <div class="container">
                <div class="row">
                    <!-- Фотография -->
                    <div class="col-md-6 col-12">
                    <img class="mt-3 mb-3" src="fotos/no_foto.jpg" style="width:100%; border-radius: 15px;">
                </div>  
                    <!-- Информация о преподавателе -->
                    <div class="col-md-6 col-12 name-prepod mt-3 mb-3">
                        <?php if (!empty($author['AFullName'])) {?> <p style="font-size: 30px;"><?= $author['AFullName']?></p> <?php } ?>


                        <?php if (!empty($author['ADate_of_Birth'])) {?> <p>Дата рождения: <?= (new DateTime($author['ADate_of_Birth']))->format('d.m.Y') ?></p> <?php } ?>
                        <p>Информация об авторе:</p>
                        <?php if (!empty($author['ADescription'])) {?> <p style="font-size: 20px;"><?= $author['ADescription']?></p> <?php } ?>
                    </div>
                </div>
            </div>

            <!-- Модальные окна -->
            <div class="modal fade" id="firstModal" role="dialog" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-body" style="padding: 0px;">
                            <button type="button" class="close" data-dismiss="modal" style="margin-right: 10px">
                                    <span aria-hidden="true">&times;</span>
                            </button>
                            <img style="width: 100%;" src="img/vimezh.jpg">
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="secondModal" role="dialog" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-body" style="padding: 0px;">
                            <button type="button" class="close" data-dismiss="modal" style="margin-right: 10px">
                                    <span aria-hidden="true">&times;</span>
                            </button>
                            <img style="width: 100%;" src="img/cprmpiter.jpg">
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="thirdModal" role="dialog" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-body" style="padding: 0px;">
                            <button type="button" class="close" data-dismiss="modal" style="margin-right: 10px">
                                    <span aria-hidden="true">&times;</span>
                            </button>
                            <img style="width: 100%;" src="img/abilympics.jpg">
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="fourthModal" role="dialog" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-body" style="padding: 0px;">
                            <button type="button" class="close" data-dismiss="modal" style="margin-right: 10px">
                                    <span aria-hidden="true">&times;</span>
                            </button>
                            <img style="width: 100%;" src="img/abilympics2.jpg">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Подвал страницы -->
        <?php include ('footer.php'); ?>
        
    </body>
</html>
