<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"> <!-- Кодировка страницы -->
        <!-- Бибдиотеки BOOTSTRAP и JQuery -->
        <link rel="stylesheet" href="lib/bootstrap-4.2.1/css/bootstrap.css">
        <script src="lib/js/jquery-3.3.1.js"></script>
        <script src="lib/js/popper.min.js"></script>
        <script src="lib/bootstrap-4.2.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css_file.css"> <!-- Мои стили -->
        <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> <!-- Шрифт -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>

<?php 
    include_once('mysql.php');
    if ($_SESSION['key']) {
        $stmt = $DB->query("SELECT Password FROM users WHERE Login LIKE '".$_SESSION['login']."'");
        $user = $stmt->fetch();
        if ($user) {
            if (md5($_SESSION['login'].$user['Password']) === $_SESSION['key']) {
                /**
                 * Кароч твоя авторизация работает, тебе осталось сделать то что жолэно происходить если авторизован, я КУШАТЬ, цалаю!
                 */
            }
        }
    }
?>

    <body>
        <div class="modal fade" style="height: 100vh;" id="vhModalDialog">
            <div class="modal-dialog row justify-content-center align-items-center" style="height: 100%;" role="document">
                <div class="modal-content" style="border-radius: 10px !important;">
                    <div class="modal-body">
                    <!-- Кнопка -->
                    <button type="button" style="width: 40px; height: 40px;" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#avt" role="tab" aria-controls="nav-home" aria-selected="true">Авторизация</a>
                            <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#reg" role="tab" aria-controls="nav-profile" aria-selected="false">Регистрация</a>
                        </div>
                    </nav>
                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade show active mt-2" id="avt" role="tabpanel" aria-labelledby="nav-home-tab">
                                <div>
                                    <div class="row align-items-center">
                                        <div class="mx-auto" id="auth-form">
                                            <div class="col-12">
                                                <span style="font-size: 20px;">Логин</span><br>
                                                <input class="form-control" type="text" id="auth-login" size="37">
                                            </div>
                                            <br>
                                            <div class="col-12">
                                                <span style="font-size: 20px;">Пароль</span><br>
                                                <input class="form-control" id="auth-pass" type="password" size="37">
                                            </div>
                                            <br>
                                            <div class="row align-items-center">
                                                <div class="mx-auto mb-2">
                                                    <input onclick="auth()" class="btn btn-outline-dark text-align-center" type="button" value="Войти">
                                                </div>
                                            </div>
                                            <script>
                                                function auth() {
                                                    let login = $('#auth-login').val(),
                                                        pass = $('#auth-pass').val();
                                                    if (login != '' && pass != '') {
                                                        $.post('register.php', {
                                                            action: 'auth',
                                                            login: login,
                                                            pass: pass
                                                        }, response => {
                                                            if (response === 'ok') {
                                                                $('#auth-form').html('Авторизация прошла успешно')
                                                            } else {
                                                                alert (response)
                                                            }
                                                        } )
                                                    }
                                                    
                                                }
                                            </script>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade mt-2" id="reg" role="tabpanel" aria-labelledby="nav-profile-tab">
                                <div class="row align-items-center">
                                    <div class="mx-auto" id="reg-form">
                                        <div class="col-12">
                                            <span style="font-size: 20px;">Логин</span><br>
                                            <input class="form-control" id="reg-login" name="tel" type="text" size="37">
                                        </div>
                                        <br>
                                        <div class="col-12">
                                            <span style="font-size: 20px;">Пароль</span><br>
                                            <input class="form-control" id="reg-pass" name="pass" type="password" size="37" onkeydown="noneHelp()">
                                            <span class="repass-and-pass" style="color: red; font-size: 15px; display: none;">Пароли не совпадают</span>
                                        </div>
                                        <br>
                                        <div class="col-12">
                                            <span style="font-size: 20px;">Подтвердите пароль</span><br>
                                            <input class="form-control" id="reg-repass" type="password" size="37" onkeydown="noneHelp()">
                                            <span class="repass-and-pass" style="color: red; font-size: 15px; display: none;">Пароли не совпадают</span>
                                        </div>
                                        <br>
                                        <div class="col-12">
                                            <span style="font-size: 20px;">Почта</span><br>
                                            <input class="form-control" id="reg-email" type="email" size="37">
                                        </div>
                                        <br>
                                        <div class="row align-items-center">
                                            <div class="mx-auto mb-2">
                                                <input class="btn btn-outline-dark text-align-center" onclick="subReg()" type="button" value="Зарегистрироваться">
                                            </div>
                                        </div>
                                        <script>
                                            function subReg()
                                            {
                                                let email = String($('#reg-email').val()),
                                                    login = String($('#reg-login').val()),
                                                    pass = String($('#reg-pass').val()),
                                                    rePass = String($('#reg-repass').val());
                                                if (email !== '' && login !== '' && pass !== '' && ( rePass !== '' && pass === rePass) )
                                                {
                                                    $.post('register.php', {
                                                        action: 'register',
                                                        pass: pass,
                                                        login: login,
                                                        email: email
                                                    }, response => {
                                                        if (response === 'ok') {
                                                            $('#reg-form').html('<center>Регистрация прошла успешно, письмо с подтверждением отправлено на Вашу почту: '+email+'</center>')
                                                        } else {
                                                            alert('Во время регистрации произошла ошибка, возможно Ваш логин занят')
                                                        }
                                                    })
                                                } else {
                                                    if (pass !== rePass) {
                                                        $('.repass-and-pass').css({'display': 'block'});
                                                    }
                                                }
                                            }
                                        function noneHelp() {
                                            $('.repass-and-pass').css({'display': 'none'});
                                        }
                                        </script>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" style="height: 100vh;" id="regModalDialog">
            <div class="modal-dialog row justify-content-center align-items-center" style="height: 100%;" role="document">
                <div class="modal-content" style="border-radius: 10px !important;">
                    <div class="modal-body">
                    <!-- Кнопка -->
                    <button type="button" style="width: 40px; height: 40px;" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" id="nav-home-tab" data-toggle="tab" href="#avt-second" role="tab" aria-controls="nav-home" aria-selected="false">Авторизация</a>
                            <a class="nav-item nav-link active" id="nav-profile-tab" data-toggle="tab" href="#reg-second" role="tab" aria-controls="nav-profile" aria-selected="true">Регистрация</a>
                        </div>
                    </nav>
                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade mt-2" id="avt-second" role="tabpanel" aria-labelledby="nav-home-tab">
                                <div>
                                    <div class="row align-items-center">
                                        <div class="mx-auto" id="auth-form-second">
                                            <div class="col-12">
                                                <span style="font-size: 20px;">Логин</span><br>
                                                <input class="form-control" type="text" id="auth-login-second" size="37">
                                            </div>
                                            <br>
                                            <div class="col-12">
                                                <span style="font-size: 20px;">Пароль</span><br>
                                                <input class="form-control" id="auth-pass-second" type="password" size="37">
                                            </div>
                                            <br>
                                            <div class="row align-items-center">
                                                <div class="mx-auto mb-2">
                                                    <input onclick="auth()" class="btn btn-outline-dark text-align-center" type="button" value="Войти">
                                                </div>
                                            </div>
                                            <script>
                                                function auth() {
                                                    let login = $('#auth-login-second').val(),
                                                        pass = $('#auth-pass-second').val();
                                                    if (login != '' && pass != '') {
                                                        $.post('register.php', {
                                                            action: 'auth',
                                                            login: login,
                                                            pass: pass
                                                        }, response => {
                                                            if (response === 'ok') {
                                                                $('#auth-form-second').html('Авторизация прошла успешно')
                                                            } else {
                                                                alert (response)
                                                            }
                                                        } )
                                                    }
                                                    
                                                }
                                            </script>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade show active mt-2" id="reg-second" role="tabpanel" aria-labelledby="nav-profile-tab">
                                <div class="row align-items-center">
                                    <div class="mx-auto" id="reg-form-second">
                                        <div class="col-12">
                                            <span style="font-size: 20px;">Логин</span><br>
                                            <input class="form-control" id="reg-login-second" name="tel" type="text" size="37">
                                        </div>
                                        <br>
                                        <div class="col-12">
                                            <span style="font-size: 20px;">Пароль</span><br>
                                            <input class="form-control" id="reg-pass-second" name="pass" type="password" size="37" onkeydown="noneHelp()">
                                            <span class="repass-and-pass" style="color: red; font-size: 15px; display: none;">Пароли не совпадают</span>
                                        </div>
                                        <br>
                                        <div class="col-12">
                                            <span style="font-size: 20px;">Подтвердите пароль</span><br>
                                            <input class="form-control" id="reg-repass-second" type="password" size="37" onkeydown="noneHelp()">
                                            <span class="repass-and-pass" style="color: red; font-size: 15px; display: none;">Пароли не совпадают</span>
                                        </div>
                                        <br>
                                        <div class="col-12">
                                            <span style="font-size: 20px;">Почта</span><br>
                                            <input class="form-control" id="reg-email-second" type="email" size="37">
                                        </div>
                                        <br>
                                        <div class="row align-items-center">
                                            <div class="mx-auto mb-2">
                                                <input class="btn btn-outline-dark text-align-center" onclick="subReg()" type="button" value="Зарегистрироваться">
                                            </div>
                                        </div>
                                        <script>
                                            function subReg()
                                            {
                                                let email = String($('#reg-email-second').val()),
                                                    login = String($('#reg-login-second').val()),
                                                    pass = String($('#reg-pass-second').val()),
                                                    rePass = String($('#reg-repass-second').val());
                                                if (email !== '' && login !== '' && pass !== '' && ( rePass !== '' && pass === rePass) )
                                                {
                                                    $.post('register.php', {
                                                        action: 'register',
                                                        pass: pass,
                                                        login: login,
                                                        email: email
                                                    }, response => {
                                                        if (response === 'ok') {
                                                            $('#reg-form-second').html('<center>Регистрация прошла успешно, письмо с подтверждением отправлено на Вашу почту: '+email+'</center>')
                                                        } else {
                                                            alert('Во время регистрации произошла ошибка, возможно Ваш логин занят')
                                                        }
                                                    })
                                                } else {
                                                    if (pass !== rePass) {
                                                        $('.repass-and-pass').css({'display': 'block'});
                                                    }
                                                }
                                            }
                                        function noneHelp() {
                                            $('.repass-and-pass').css({'display': 'none'});
                                        }
                                        </script>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>