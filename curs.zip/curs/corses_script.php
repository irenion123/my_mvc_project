<?php
error_reporting(0);
$link = new mysqli("localhost", "annalegx_99", "annalegx_99", "3987egalov");
$link->set_charset("utf8");
$names = Array();
$sql_name = "SELECT `name` FROM course";
$result = $link -> query($sql_name);
$sql_info = Array();
foreach ($result as $value) {
	$sql_info[] = $value['name'];
}
$newoptions = Array();
foreach($sql_info as $value){
	if(!in_array($value, $_POST['nameoptions'])){
		$newoptions['course_name'][] = $value;
	}
}
if($_POST['activename']){
	$sql_time = "SELECT `name`, `date_course` FROM course WHERE `name` = '".$_POST['activename']."'";
	$result3 = $link -> query($sql_time);
	foreach ($result3 as $value) {
		$newoptions['date_course'][] = $value['date_course'];
	}
}
echo json_encode($newoptions);
?>