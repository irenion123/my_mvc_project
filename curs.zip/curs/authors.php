<?php 
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include ('database/connection.php'); ?>
        <meta charset="utf-8"> <!-- Кодировка страницы -->
        <!-- Бибдиотеки BOOTSTRAP и JQuery -->
        <link rel="stylesheet" href="lib/bootstrap-4.2.1/css/bootstrap.css">
        <script src="lib/js/jquery-3.3.1.js"></script>
        <script src="lib/js/popper.min.js"></script>
        <script src="lib/bootstrap-4.2.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css_file.css"> <!-- Мои стили -->
        <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> <!-- Шрифт -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>О нас</title>
    </head>
    <body>
        <?php include ('header.php'); ?>

        <?php 
        //include ('database/entities.php'); 
        $conn = new MyConnection();
        ?>

        <div class="main">
            
            <!-- Преподаватели -->
            <div style="padding-top: 25px; padding-bottom: 25px;">
                <div id="kursi" class="container">
                    <h1><span class="letter">Н</span>аши авторы.</h1></br>
                    <div class="row" style="text-align: center;">

                        <?php foreach ($conn->getAuthors() as $author) { ?>
                        <div class="col-lg-4 col-sm-6 col-6 pr" style="margin-bottom: 30px;">
                            <a class="name-prepod" href="view_author.php?author_id=<?= $author["id_Author"] ?>">
                                <div class="book-image bg-white" style="background: url('<?= $author['Foto'] ?>'); background-size: cover; background-position: center;"></div>
                                <span><?= $author['AFullName'] ?></span>
                            </a> 
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Подвал страницы -->
        <?php include ('footer.php'); ?>

    </body>
</html>