<?php
            $host = 'localhost';  // Хост, у нас все локально
            $user = 'root';    // Имя созданного вами пользователя
            $password = 'root'; // Установленный вами пароль пользователю
            $db_name = 'db_students';   // Имя базы данных
            $link = mysqli_connect($host, $user, $password, $db_name); // Соединяемся с базой
            // Ругаемся, если соединение установить не удалось
            if (!$link) {
                echo 'Не удается соединиться с БД. Код ошибки: ' . mysqli_connect_errno() . ', ошибка: ' . mysqli_connect_error();
                exit;
            }
    
            $query ="SELECT * FROM students";
            $result = mysqli_query($link, $query) or die("Ошибка " . mysqli_error($link)); 
        ?>