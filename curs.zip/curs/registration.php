<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"> <!-- Кодировка страницы -->
        <!-- Бибдиотеки BOOTSTRAP и JQuery -->
        <link rel="stylesheet" href="lib/bootstrap-4.2.1/css/bootstrap.css">
        <script src="lib/js/jquery-3.3.1.js"></script>
        <script src="lib/js/popper.min.js"></script>
        <script src="lib/bootstrap-4.2.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css_file.css"> <!-- Мои стили -->
        <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'> <!-- Шрифт -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Регистрация</title>
    </head>
    <body>
        <?php include ('header.php'); ?>
        <div class="main">

        <!-- Шапка страницы -->
        

        <form action="auth.php"  method="post">
            <div style="padding-bottom: 50px;">
                <div class="container">

                    <div class="container form-group card mt-5 p-4">
                        <h2 class="text-center pb-3">
                            Регистрация/<a href="sign_in.php">Вход</a>
                        </h2>
                        <?php if ( !empty($_GET['error']) ) {
                            if ($_GET['error'] == 'email_taken') { ?>
                            <div class="alert alert-danger">
                                Выбранный почтовый адрес уже используется
                            </div>
                            <?php } else if ($_GET['error'] == 'password_mismatch'){ ?>
                            <div class="alert alert-danger">
                                Пароли не совпадают
                            </div>
                            <?php } else { ?>
                                <div class="toast">
                                Ошибка!
                                </div>
                            <?php } ?>
                        <?php } ?>
                        <div class="row" id="reg-form">
                            <div class="col-sm">
                                <label style="font-size: 25px">Имя</label>
                                <input type="text" class="form-control" name="first_name" placeholder="Введите Ваше имя" required>
                            </div>
                            <div class="col-sm">
                                <label style="font-size: 25px">Дата рождения</label>
                                <input type="date" class="form-control" name="birth_date" required>
                            </div>
                        </div>

                        <div class="row mt-4">
                            <div class="col-sm">
                                <label style="font-size: 25px">E-mail</label>
                                <input type="email" class="form-control" name="email" placeholder="Введите Вашу электронную почту" required>
                                <small class="form-text text-muted">Мы никогда не сообщим Ваш адрес электронной почты кому-либо.</small>
                            </div>
                        </div>

                        <div class="row mt-4">
                            <div class="col-sm">
                                <label style="font-size: 25px">Пароль</label>
                                <input type="password" class="form-control" name="password" placeholder="Введите пароль" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm">
                                <label style="font-size: 25px">Повторите пароль</label>
                                <input type="password" class="form-control" name="password_confirmation" placeholder="Повторите пароль" required> 
                            </div>
                        </div>

                        <div class="mt-4 text-center">
                            <button class="btn btn-light" type="submit" name="action" value="register" style="font-size: 20px">
                                Зарегистрироваться
                            </button>
                        </div>
                    </div> 
                </div>
            </div>
        </form>
        
        </div>
        
        <!-- Подвал страницы -->
        <?php include ('footer.php'); ?>
        
    </body>
</html>