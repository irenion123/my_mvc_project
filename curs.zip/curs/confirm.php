<?php
    include('mysql.php');

    if ($_GET['confirm_code']) {
        $stmt = $DB->query("SELECT ID_users, is_confirm FROM users_info WHERE code_confirm LIKE '".$_GET['confirm_code']."'");
        $user = $stmt->fetch();
        if ($user) {
            if ($user['is_confirm'] == 0) {
                $DB->exec("UPDATE users_info SET is_confirm=1 WHERE ID_users=".$user['ID_users']);
                var_dump($user);
            }
        }
    }
?>